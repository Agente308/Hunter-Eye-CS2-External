﻿#pragma once
#include "common.h"
#include "process.h"  
#include <thread>
#include <atomic>
#include <queue>

class MemoryManager {
public:
    struct ReadTask {
        uintptr_t address;
        void* buffer;
        size_t size;
        std::function<void(bool)> callback;

        ReadTask() : address(0), buffer(nullptr), size(0), callback(nullptr) {}
        ReadTask(uintptr_t addr, void* buf, size_t sz, std::function<void(bool)> cb = nullptr)
            : address(addr), buffer(buf), size(sz), callback(cb) {
        }
    };

    struct PlayerReadData {
        uintptr_t baseAddress;
        float health;
        float armor;
        Vector3 origin;
        Vector3 head;
        int team;
        bool valid;
    };

private:
    std::shared_ptr<pProcess> process_;
    std::atomic<bool> running_;
    std::thread workerThread_;

    std::queue<ReadTask> taskQueue_;
    std::mutex queueMutex_;
    std::condition_variable queueCV_;

    static constexpr size_t BUFFER_POOL_SIZE = 64;
    std::vector<std::unique_ptr<uint8_t[]>> bufferPool_;
    std::mutex poolMutex_;

    std::atomic<uint64_t> totalReads_{ 0 };
    std::atomic<uint64_t> failedReads_{ 0 };
    std::atomic<uint64_t> cachedReads_{ 0 };

public:
    MemoryManager(std::shared_ptr<pProcess> process) : process_(process), running_(false) {
        bufferPool_.reserve(BUFFER_POOL_SIZE);
        for (size_t i = 0; i < BUFFER_POOL_SIZE; ++i) {
            bufferPool_.push_back(std::make_unique<uint8_t[]>(4096));
        }
    }

    ~MemoryManager() {
        Stop();
    }

    void Start() {
        if (running_) return;
        running_ = true;
        workerThread_ = std::thread(&MemoryManager::WorkerLoop, this);
    }

    void Stop() {
        if (!running_) return;
        running_ = false;
        queueCV_.notify_all();
        if (workerThread_.joinable()) {
            workerThread_.join();
        }
    }

    void ReadAsync(uintptr_t address, void* buffer, size_t size,
        std::function<void(bool)> callback = nullptr) {
        ReadTask task{ address, buffer, size, callback };
        {
            std::lock_guard<std::mutex> lock(queueMutex_);
            taskQueue_.push(task);
        }
        queueCV_.notify_one();
    }

    bool ReadPlayersBulk(const std::vector<uintptr_t>& playerAddresses,
        std::vector<PlayerReadData>& outData) {
        if (!process_ || playerAddresses.empty()) return false;

        outData.resize(playerAddresses.size());
        std::vector<BatchReadRequest> requests;
        requests.reserve(playerAddresses.size() * 6);

        for (size_t i = 0; i < playerAddresses.size(); ++i) {
            uintptr_t base = playerAddresses[i];
            const uintptr_t HEALTH_OFFSET = 0x100;
            const uintptr_t ARMOR_OFFSET = 0x104;
            const uintptr_t ORIGIN_OFFSET = 0x138;
            const uintptr_t TEAM_OFFSET = 0xF4;

            requests.push_back(BatchReadRequest(base + HEALTH_OFFSET, &outData[i].health, sizeof(float)));
            requests.push_back(BatchReadRequest(base + ARMOR_OFFSET, &outData[i].armor, sizeof(float)));
            requests.push_back(BatchReadRequest(base + ORIGIN_OFFSET, &outData[i].origin, sizeof(Vector3)));
            requests.push_back(BatchReadRequest(base + TEAM_OFFSET, &outData[i].team, sizeof(int)));

            outData[i].baseAddress = base;
            outData[i].valid = false;
        }

        bool success = process_->read_batch_variable(requests);

        if (success) {
            for (auto& data : outData) {
                data.valid = true;
            }
        }

        totalReads_ += requests.size();
        if (!success) failedReads_++;

        return success;
    }

    template<typename T>
    bool ReadContiguous(uintptr_t baseAddress, std::vector<T>& outData, size_t count) {
        if (!process_) return false;
        outData.resize(count);
        size_t totalSize = sizeof(T) * count;
        bool success = process_->read_bulk(baseAddress, outData.data(), totalSize);
        totalReads_++;
        if (!success) failedReads_++;
        return success;
    }

    bool ReadScatterGather(const std::vector<std::pair<uintptr_t, size_t>>& regions,
        std::vector<std::vector<uint8_t>>& outBuffers) {
        if (!process_ || regions.empty()) return false;
        outBuffers.resize(regions.size());

        for (size_t i = 0; i < regions.size(); ++i) {
            auto& [address, size] = regions[i];
            outBuffers[i].resize(size);

            if (!process_->read_raw(address, outBuffers[i].data(), size)) {
                failedReads_++;
                return false;
            }
        }

        totalReads_ += regions.size();
        return true;
    }

    uint8_t* GetBuffer() {
        std::lock_guard<std::mutex> lock(poolMutex_);
        if (!bufferPool_.empty()) {
            auto buffer = bufferPool_.back().release();
            bufferPool_.pop_back();
            return buffer;
        }
        return new uint8_t[4096];
    }

    void ReturnBuffer(uint8_t* buffer) {
        std::lock_guard<std::mutex> lock(poolMutex_);
        if (bufferPool_.size() < BUFFER_POOL_SIZE) {
            bufferPool_.push_back(std::unique_ptr<uint8_t[]>(buffer));
        }
        else {
            delete[] buffer;
        }
    }

    struct Stats {
        uint64_t totalReads;
        uint64_t failedReads;
        uint64_t cachedReads;
        float successRate;
        float cacheHitRate;
    };

    Stats GetStats() const {
        Stats stats;
        stats.totalReads = totalReads_.load();
        stats.failedReads = failedReads_.load();
        stats.cachedReads = cachedReads_.load();

        if (stats.totalReads > 0) {
            stats.successRate = 1.0f - (float)stats.failedReads / stats.totalReads;
            stats.cacheHitRate = (float)stats.cachedReads / stats.totalReads;
        }
        else {
            stats.successRate = 0.0f;
            stats.cacheHitRate = 0.0f;
        }

        return stats;
    }

    void ResetStats() {
        totalReads_ = 0;
        failedReads_ = 0;
        cachedReads_ = 0;
    }

private:
    void WorkerLoop() {
        while (running_) {
            ReadTask task;

            {
                std::unique_lock<std::mutex> lock(queueMutex_);
                queueCV_.wait(lock, [this] {
                    return !taskQueue_.empty() || !running_;
                    });

                if (!running_) break;
                if (taskQueue_.empty()) continue;

                task = taskQueue_.front();
                taskQueue_.pop();
            }

            bool success = process_->read_raw(task.address, task.buffer, task.size);

            totalReads_++;
            if (!success) failedReads_++;

            if (task.callback) {
                task.callback(success);
            }
        }
    }
};

inline MemoryManager* g_MemoryManager = nullptr;