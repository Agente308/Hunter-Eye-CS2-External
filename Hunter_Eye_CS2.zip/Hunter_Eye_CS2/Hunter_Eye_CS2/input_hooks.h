#pragma once
#include "common.h"

namespace InputHooks {
    extern bool g_MenuOpen;
    extern HWND g_GameWindow;
    extern HWND g_OverlayWindow;

    bool Initialize(HWND gameWindow, HWND overlayWindow);
    void Shutdown();
    void Update();
    void SetMenuState(bool open);
}