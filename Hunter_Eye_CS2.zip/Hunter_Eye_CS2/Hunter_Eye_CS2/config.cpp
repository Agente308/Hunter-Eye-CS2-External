﻿#include "config.h"
#include <fstream>
#include <sstream>
#include <iostream>

Config g_config;

namespace {
    std::string readFile(const char* filename) {
        std::ifstream file(filename);
        if (!file.is_open()) {
            return "";
        }

        std::stringstream buffer;
        buffer << file.rdbuf();
        return buffer.str();
    }

    int findIntValue(const std::string& json, const std::string& key) {
        std::string searchKey = "\"" + key + "\":";
        size_t pos = json.find(searchKey);

        if (pos == std::string::npos) {
            return 0;
        }

        size_t start = pos + searchKey.length();

        while (start < json.length() && (json[start] == ' ' || json[start] == '\t' || json[start] == '\n')) {
            start++;
        }

        std::string numStr;
        while (start < json.length() && (isdigit(json[start]) || json[start] == '-')) {
            numStr += json[start++];
        }

        if (numStr.empty()) {
            return 0;
        }

        try {
            return std::stoi(numStr);
        }
        catch (...) {
            return 0;
        }
    }

    float findFloatValue(const std::string& json, const std::string& key) {
        std::string searchKey = "\"" + key + "\":";
        size_t pos = json.find(searchKey);

        if (pos == std::string::npos) {
            return 0.0f;
        }

        size_t start = pos + searchKey.length();

        while (start < json.length() && (json[start] == ' ' || json[start] == '\t' || json[start] == '\n')) {
            start++;
        }

        std::string numStr;
        while (start < json.length() && (isdigit(json[start]) || json[start] == '.' || json[start] == '-')) {
            numStr += json[start++];
        }

        if (numStr.empty()) {
            return 0.0f;
        }

        try {
            return std::stof(numStr);
        }
        catch (...) {
            return 0.0f;
        }
    }

    bool findBoolValue(const std::string& json, const std::string& key) {
        std::string searchKey = "\"" + key + "\":";
        size_t pos = json.find(searchKey);

        if (pos == std::string::npos) {
            return false;
        }

        size_t start = pos + searchKey.length();

        while (start < json.length() && (json[start] == ' ' || json[start] == '\t' || json[start] == '\n')) {
            start++;
        }

        return (start < json.length() && json[start] == 't');
    }
}

void ConfigLoader::LoadConfig() {
    std::string json = readFile("hunter_eye_config.json");

    if (json.empty()) {
        std::cout << "[*] No config file found, using defaults" << std::endl;

        g_config.show_box_esp = true;
        g_config.show_names = true;
        g_config.show_health_bar = true;
        g_config.team_esp = true;
        g_config.ignore_teammates = false;
        g_config.ignore_enemies = false;
        g_config.render_distance = 10000.0f;
        g_config.box_thickness = 2;
        g_config.esp_line_style = ESP_STYLE_NORMAL;

        return;
    }

    std::cout << "[*] Loading configuration from hunter_eye_config.json" << std::endl;

    g_config.show_box_esp = findBoolValue(json, "show_box_esp");
    g_config.show_filled_box = findBoolValue(json, "show_filled_box");
    g_config.show_head_tracker = findBoolValue(json, "show_head_tracker");
    g_config.show_skeleton_esp = findBoolValue(json, "show_skeleton_esp");
    g_config.show_snaplines = findBoolValue(json, "show_snaplines");
    g_config.show_health_bar = findBoolValue(json, "show_health_bar");
    g_config.show_armor_bar = findBoolValue(json, "show_armor_bar");
    g_config.show_distance = findBoolValue(json, "show_distance");
    g_config.show_names = findBoolValue(json, "show_names");
    g_config.team_esp = findBoolValue(json, "team_esp");
    g_config.use_corner_box = findBoolValue(json, "use_corner_box");
    g_config.ignore_teammates = findBoolValue(json, "ignore_teammates");
    g_config.ignore_enemies = findBoolValue(json, "ignore_enemies");

    g_config.box_thickness = findIntValue(json, "box_thickness");
    if (g_config.box_thickness < 1) g_config.box_thickness = 1;

    g_config.skeleton_thickness = findIntValue(json, "skeleton_thickness");
    if (g_config.skeleton_thickness < 1) g_config.skeleton_thickness = 1;

    g_config.snapline_thickness = findIntValue(json, "snapline_thickness");
    if (g_config.snapline_thickness < 1) g_config.snapline_thickness = 1;

    g_config.filled_box_alpha = findIntValue(json, "filled_box_alpha");
    if (g_config.filled_box_alpha < 0) g_config.filled_box_alpha = 0;
    if (g_config.filled_box_alpha > 255) g_config.filled_box_alpha = 255;

    int styleValue = findIntValue(json, "esp_line_style");
    if (styleValue >= 0 && styleValue <= 5) {
        g_config.esp_line_style = (ESPLineStyle)styleValue;
    }

    g_config.glow_intensity = findIntValue(json, "glow_intensity");
    if (g_config.glow_intensity < 1) g_config.glow_intensity = 3;
    if (g_config.glow_intensity > 5) g_config.glow_intensity = 5;

    g_config.glow_blur_radius = findIntValue(json, "glow_blur_radius");
    if (g_config.glow_blur_radius < 2) g_config.glow_blur_radius = 8;
    if (g_config.glow_blur_radius > 20) g_config.glow_blur_radius = 20;

    g_config.glow_alpha_falloff = findFloatValue(json, "glow_alpha_falloff");
    if (g_config.glow_alpha_falloff < 0.3f) g_config.glow_alpha_falloff = 0.5f;
    if (g_config.glow_alpha_falloff > 0.9f) g_config.glow_alpha_falloff = 0.9f;

    g_config.outline_thickness = findIntValue(json, "outline_thickness");
    if (g_config.outline_thickness < 1) g_config.outline_thickness = 2;
    if (g_config.outline_thickness > 5) g_config.outline_thickness = 5;

    size_t outline_color_pos = json.find("\"outline_color\"");
    if (outline_color_pos != std::string::npos) {
        std::string section = json.substr(outline_color_pos, 200);
        g_config.outline_color.r = findIntValue(section, "r");
        g_config.outline_color.g = findIntValue(section, "g");
        g_config.outline_color.b = findIntValue(section, "b");
    }

    g_config.dot_spacing = findIntValue(json, "dot_spacing");
    if (g_config.dot_spacing < 2) g_config.dot_spacing = 5;
    if (g_config.dot_spacing > 15) g_config.dot_spacing = 15;

    g_config.dot_length = findIntValue(json, "dot_length");
    if (g_config.dot_length < 1) g_config.dot_length = 3;
    if (g_config.dot_length > 20) g_config.dot_length = 20;

    size_t box_color_pos = json.find("\"box_color_enemy\"");
    if (box_color_pos != std::string::npos) {
        std::string section = json.substr(box_color_pos, 200);
        g_config.box_color_enemy.r = findIntValue(section, "r");
        g_config.box_color_enemy.g = findIntValue(section, "g");
        g_config.box_color_enemy.b = findIntValue(section, "b");
    }

    size_t filled_color_pos = json.find("\"filled_box_color_enemy\"");
    if (filled_color_pos != std::string::npos) {
        std::string section = json.substr(filled_color_pos, 200);
        g_config.filled_box_color_enemy.r = findIntValue(section, "r");
        g_config.filled_box_color_enemy.g = findIntValue(section, "g");
        g_config.filled_box_color_enemy.b = findIntValue(section, "b");
    }

    size_t skel_color_pos = json.find("\"skeleton_color_enemy\"");
    if (skel_color_pos != std::string::npos) {
        std::string section = json.substr(skel_color_pos, 200);
        g_config.skeleton_color_enemy.r = findIntValue(section, "r");
        g_config.skeleton_color_enemy.g = findIntValue(section, "g");
        g_config.skeleton_color_enemy.b = findIntValue(section, "b");
    }

    size_t team_box_pos = json.find("\"box_color_team\"");
    if (team_box_pos != std::string::npos) {
        std::string section = json.substr(team_box_pos, 200);
        g_config.box_color_team.r = findIntValue(section, "r");
        g_config.box_color_team.g = findIntValue(section, "g");
        g_config.box_color_team.b = findIntValue(section, "b");
    }

    size_t team_skel_pos = json.find("\"skeleton_color_team\"");
    if (team_skel_pos != std::string::npos) {
        std::string section = json.substr(team_skel_pos, 200);
        g_config.skeleton_color_team.r = findIntValue(section, "r");
        g_config.skeleton_color_team.g = findIntValue(section, "g");
        g_config.skeleton_color_team.b = findIntValue(section, "b");
    }

    size_t head_enemy_pos = json.find("\"head_color_enemy\"");
    if (head_enemy_pos != std::string::npos) {
        std::string section = json.substr(head_enemy_pos, 200);
        g_config.head_color_enemy.r = findIntValue(section, "r");
        g_config.head_color_enemy.g = findIntValue(section, "g");
        g_config.head_color_enemy.b = findIntValue(section, "b");
    }

    size_t head_team_pos = json.find("\"head_color_team\"");
    if (head_team_pos != std::string::npos) {
        std::string section = json.substr(head_team_pos, 200);
        g_config.head_color_team.r = findIntValue(section, "r");
        g_config.head_color_team.g = findIntValue(section, "g");
        g_config.head_color_team.b = findIntValue(section, "b");
    }

    g_config.show_radar = findBoolValue(json, "show_radar");
    g_config.radar_show_names = findBoolValue(json, "radar_show_names");
    g_config.radar_x = findFloatValue(json, "radar_x");
    g_config.radar_y = findFloatValue(json, "radar_y");
    g_config.radar_size = findFloatValue(json, "radar_size");
    g_config.radar_zoom = findFloatValue(json, "radar_zoom");

    if (g_config.radar_size < 50.0f) g_config.radar_size = 50.0f;
    if (g_config.radar_size > 500.0f) g_config.radar_size = 500.0f;
    if (g_config.radar_zoom < 500.0f) g_config.radar_zoom = 500.0f;

    g_config.show_bomb_timer = findBoolValue(json, "show_bomb_timer");
    g_config.bomb_timer_x = findFloatValue(json, "bomb_timer_x");
    g_config.bomb_timer_y = findFloatValue(json, "bomb_timer_y");

    g_triggerbot.enabled = findBoolValue(json, "triggerbot_enabled");
    g_triggerbot.trigger_delay = findIntValue(json, "trigger_delay");
    if (g_triggerbot.trigger_delay < 20) g_triggerbot.trigger_delay = 20;
    if (g_triggerbot.trigger_delay > 200) g_triggerbot.trigger_delay = 200;

    g_triggerbot.scope_only = findBoolValue(json, "scope_only");
    g_triggerbot.ignore_flash = findBoolValue(json, "ignore_flash");
    g_triggerbot.stopped_only = findBoolValue(json, "stopped_only");
    g_triggerbot.team_check = findBoolValue(json, "team_check");

    g_keybinds.esp_toggle = findIntValue(json, "keybind_esp_toggle");
    if (g_keybinds.esp_toggle == 0) g_keybinds.esp_toggle = VK_F1;

    g_keybinds.radar_toggle = findIntValue(json, "keybind_radar_toggle");
    if (g_keybinds.radar_toggle == 0) g_keybinds.radar_toggle = VK_F2;

    g_keybinds.bomb_toggle = findIntValue(json, "keybind_bomb_toggle");
    if (g_keybinds.bomb_toggle == 0) g_keybinds.bomb_toggle = VK_F3;

    g_keybinds.triggerbot_toggle = findIntValue(json, "keybind_triggerbot_toggle");
    if (g_keybinds.triggerbot_toggle == 0) g_keybinds.triggerbot_toggle = VK_F4;

    g_triggerbot.hotkey = findIntValue(json, "triggerbot_hotkey");
    if (g_triggerbot.hotkey == 0) g_triggerbot.hotkey = 0x43;

    g_config.fov_changer_enabled = findBoolValue(json, "fov_changer_enabled");
    g_config.desired_fov = findIntValue(json, "desired_fov");
    if (g_config.desired_fov < 60) g_config.desired_fov = 60;
    if (g_config.desired_fov > 140) g_config.desired_fov = 140;
    g_config.fov_ignore_scope = findBoolValue(json, "fov_ignore_scope");

    g_config.bhop_enabled = findBoolValue(json, "bhop_enabled");
    g_config.bhop_delay = findIntValue(json, "bhop_delay");
    if (g_config.bhop_delay < 5) g_config.bhop_delay = 5;
    if (g_config.bhop_delay > 50) g_config.bhop_delay = 50;

    g_config.render_distance = findFloatValue(json, "render_distance");
    if (g_config.render_distance < 0.0f) g_config.render_distance = 0.0f;
    if (g_config.render_distance > 20000.0f) g_config.render_distance = 20000.0f;

    g_config.glow_enabled = findBoolValue(json, "glow_enabled");
    g_config.glow_enemies = findBoolValue(json, "glow_enemies");
    g_config.glow_teammates = findBoolValue(json, "glow_teammates");

    g_config.glow_type = findIntValue(json, "glow_type");
    if (g_config.glow_type < 0) g_config.glow_type = 0;
    if (g_config.glow_type > 3) g_config.glow_type = 3;

    g_config.glow_alpha = findIntValue(json, "glow_alpha");
    if (g_config.glow_alpha < 0) g_config.glow_alpha = 0;
    if (g_config.glow_alpha > 255) g_config.glow_alpha = 255;

    size_t glow_enemy_pos = json.find("\"glow_color_enemy\"");
    if (glow_enemy_pos != std::string::npos) {
        std::string section = json.substr(glow_enemy_pos, 200);
        g_config.glow_color_enemy.r = findIntValue(section, "r");
        g_config.glow_color_enemy.g = findIntValue(section, "g");
        g_config.glow_color_enemy.b = findIntValue(section, "b");
    }

    size_t glow_team_pos = json.find("\"glow_color_team\"");
    if (glow_team_pos != std::string::npos) {
        std::string section = json.substr(glow_team_pos, 200);
        g_config.glow_color_team.r = findIntValue(section, "r");
        g_config.glow_color_team.g = findIntValue(section, "g");
        g_config.glow_color_team.b = findIntValue(section, "b");
    }

    std::cout << "[+] Configuration loaded successfully!" << std::endl;
    std::cout << "[+] ESP Style: " << (int)g_config.esp_line_style << " (";

    switch (g_config.esp_line_style) {
    case ESP_STYLE_NORMAL: std::cout << "Normal"; break;
    case ESP_STYLE_GLOW: std::cout << "Glow"; break;
    case ESP_STYLE_OUTLINED: std::cout << "Outlined"; break;
    case ESP_STYLE_DOTTED: std::cout << "Dotted"; break;
    case ESP_STYLE_DASHED: std::cout << "Dashed"; break;
    case ESP_STYLE_GRADIENT: std::cout << "Gradient"; break;
    }

    std::cout << ")" << std::endl;
}

void ConfigLoader::SaveConfig() {
    std::ofstream file("hunter_eye_config.json");
    if (!file.is_open()) {
        std::cerr << "[ERROR] Could not save config file" << std::endl;
        return;
    }

    file << "{\n";

    file << "  \"show_box_esp\": " << (g_config.show_box_esp ? "true" : "false") << ",\n";
    file << "  \"show_filled_box\": " << (g_config.show_filled_box ? "true" : "false") << ",\n";
    file << "  \"show_head_tracker\": " << (g_config.show_head_tracker ? "true" : "false") << ",\n";
    file << "  \"show_skeleton_esp\": " << (g_config.show_skeleton_esp ? "true" : "false") << ",\n";
    file << "  \"show_snaplines\": " << (g_config.show_snaplines ? "true" : "false") << ",\n";
    file << "  \"show_health_bar\": " << (g_config.show_health_bar ? "true" : "false") << ",\n";
    file << "  \"show_armor_bar\": " << (g_config.show_armor_bar ? "true" : "false") << ",\n";
    file << "  \"show_distance\": " << (g_config.show_distance ? "true" : "false") << ",\n";
    file << "  \"show_names\": " << (g_config.show_names ? "true" : "false") << ",\n";
    file << "  \"team_esp\": " << (g_config.team_esp ? "true" : "false") << ",\n";
    file << "  \"use_corner_box\": " << (g_config.use_corner_box ? "true" : "false") << ",\n";
    file << "  \"ignore_teammates\": " << (g_config.ignore_teammates ? "true" : "false") << ",\n";
    file << "  \"ignore_enemies\": " << (g_config.ignore_enemies ? "true" : "false") << ",\n";

    file << "  \"box_thickness\": " << g_config.box_thickness << ",\n";
    file << "  \"skeleton_thickness\": " << g_config.skeleton_thickness << ",\n";
    file << "  \"snapline_thickness\": " << g_config.snapline_thickness << ",\n";
    file << "  \"filled_box_alpha\": " << g_config.filled_box_alpha << ",\n";

    file << "  \"esp_line_style\": " << (int)g_config.esp_line_style << ",\n";
    file << "  \"glow_intensity\": " << g_config.glow_intensity << ",\n";
    file << "  \"glow_blur_radius\": " << g_config.glow_blur_radius << ",\n";
    file << "  \"glow_alpha_falloff\": " << g_config.glow_alpha_falloff << ",\n";
    file << "  \"outline_thickness\": " << g_config.outline_thickness << ",\n";
    file << "  \"outline_color\": { \"r\": " << g_config.outline_color.r
        << ", \"g\": " << g_config.outline_color.g
        << ", \"b\": " << g_config.outline_color.b << " },\n";
    file << "  \"dot_spacing\": " << g_config.dot_spacing << ",\n";
    file << "  \"dot_length\": " << g_config.dot_length << ",\n";

    file << "  \"box_color_enemy\": { \"r\": " << g_config.box_color_enemy.r
        << ", \"g\": " << g_config.box_color_enemy.g
        << ", \"b\": " << g_config.box_color_enemy.b << " },\n";

    file << "  \"box_color_team\": { \"r\": " << g_config.box_color_team.r
        << ", \"g\": " << g_config.box_color_team.g
        << ", \"b\": " << g_config.box_color_team.b << " },\n";

    file << "  \"skeleton_color_enemy\": { \"r\": " << g_config.skeleton_color_enemy.r
        << ", \"g\": " << g_config.skeleton_color_enemy.g
        << ", \"b\": " << g_config.skeleton_color_enemy.b << " },\n";

    file << "  \"skeleton_color_team\": { \"r\": " << g_config.skeleton_color_team.r
        << ", \"g\": " << g_config.skeleton_color_team.g
        << ", \"b\": " << g_config.skeleton_color_team.b << " },\n";

    file << "  \"head_color_enemy\": { \"r\": " << g_config.head_color_enemy.r
        << ", \"g\": " << g_config.head_color_enemy.g
        << ", \"b\": " << g_config.head_color_enemy.b << " },\n";

    file << "  \"head_color_team\": { \"r\": " << g_config.head_color_team.r
        << ", \"g\": " << g_config.head_color_team.g
        << ", \"b\": " << g_config.head_color_team.b << " },\n";

    file << "  \"filled_box_color_enemy\": { \"r\": " << g_config.filled_box_color_enemy.r
        << ", \"g\": " << g_config.filled_box_color_enemy.g
        << ", \"b\": " << g_config.filled_box_color_enemy.b << " },\n";

    file << "  \"show_radar\": " << (g_config.show_radar ? "true" : "false") << ",\n";
    file << "  \"radar_show_names\": " << (g_config.radar_show_names ? "true" : "false") << ",\n";
    file << "  \"radar_x\": " << g_config.radar_x << ",\n";
    file << "  \"radar_y\": " << g_config.radar_y << ",\n";
    file << "  \"radar_size\": " << g_config.radar_size << ",\n";
    file << "  \"radar_zoom\": " << g_config.radar_zoom << ",\n";

    file << "  \"show_bomb_timer\": " << (g_config.show_bomb_timer ? "true" : "false") << ",\n";
    file << "  \"bomb_timer_x\": " << g_config.bomb_timer_x << ",\n";
    file << "  \"bomb_timer_y\": " << g_config.bomb_timer_y << ",\n";

    file << "  \"triggerbot_enabled\": " << (g_triggerbot.enabled ? "true" : "false") << ",\n";
    file << "  \"trigger_delay\": " << g_triggerbot.trigger_delay << ",\n";
    file << "  \"scope_only\": " << (g_triggerbot.scope_only ? "true" : "false") << ",\n";
    file << "  \"ignore_flash\": " << (g_triggerbot.ignore_flash ? "true" : "false") << ",\n";
    file << "  \"stopped_only\": " << (g_triggerbot.stopped_only ? "true" : "false") << ",\n";
    file << "  \"team_check\": " << (g_triggerbot.team_check ? "true" : "false") << ",\n";
    file << "  \"triggerbot_hotkey\": " << g_triggerbot.hotkey << ",\n";

    file << "  \"fov_changer_enabled\": " << (g_config.fov_changer_enabled ? "true" : "false") << ",\n";
    file << "  \"desired_fov\": " << g_config.desired_fov << ",\n";
    file << "  \"fov_ignore_scope\": " << (g_config.fov_ignore_scope ? "true" : "false") << ",\n";

    file << "  \"bhop_enabled\": " << (g_config.bhop_enabled ? "true" : "false") << ",\n";
    file << "  \"bhop_delay\": " << g_config.bhop_delay << ",\n";

    file << "  \"glow_enabled\": " << (g_config.glow_enabled ? "true" : "false") << ",\n";
    file << "  \"glow_enemies\": " << (g_config.glow_enemies ? "true" : "false") << ",\n";
    file << "  \"glow_teammates\": " << (g_config.glow_teammates ? "true" : "false") << ",\n";
    file << "  \"glow_type\": " << g_config.glow_type << ",\n";
    file << "  \"glow_alpha\": " << g_config.glow_alpha << ",\n";

    file << "  \"glow_color_enemy\": { \"r\": " << g_config.glow_color_enemy.r
        << ", \"g\": " << g_config.glow_color_enemy.g
        << ", \"b\": " << g_config.glow_color_enemy.b << " },\n";

    file << "  \"glow_color_team\": { \"r\": " << g_config.glow_color_team.r
        << ", \"g\": " << g_config.glow_color_team.g
        << ", \"b\": " << g_config.glow_color_team.b << " },\n";

    file << "  \"render_distance\": " << g_config.render_distance << ",\n";

    file << "  \"keybind_esp_toggle\": " << g_keybinds.esp_toggle << ",\n";
    file << "  \"keybind_radar_toggle\": " << g_keybinds.radar_toggle << ",\n";
    file << "  \"keybind_bomb_toggle\": " << g_keybinds.bomb_toggle << ",\n";
    file << "  \"keybind_triggerbot_toggle\": " << g_keybinds.triggerbot_toggle << "\n";

    file << "}\n";

    file.close();
    std::cout << "[+] Configuration saved successfully!" << std::endl;
}

void ConfigLoader::LoadDefaultConfig() {

}

void ConfigLoader::LoadPerformanceConfig() {

}

void ConfigLoader::SavePerformanceConfig() {

}