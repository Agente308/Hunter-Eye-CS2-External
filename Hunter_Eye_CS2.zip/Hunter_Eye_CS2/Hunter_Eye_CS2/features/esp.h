#pragma once
#include "../common.h"
#include "../game.h"

namespace ESP {
    void Render();
}