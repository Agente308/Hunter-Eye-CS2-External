#include "bhop.h"

AutoBhop::AutoBhop(std::shared_ptr<pProcess> proc, ProcessModule client, uintptr_t forceJumpOffset)
    : process(proc), base_client(client), dwForceJump(forceJumpOffset),
    jumpState(false), jumpCount(0), was_space_pressed(false) {
    lastToggleTime = std::chrono::steady_clock::now();
}

void AutoBhop::Run(int delay_ms, bool enabled, DWORD cs2_pid) {
    if (!enabled || !process || !process->handle_) return;

    if (!IsCS2Active(cs2_pid)) {
        ResetJump();
        return;
    }

    bool spacePressed = (GetAsyncKeyState(VK_SPACE) & 0x8000) != 0;

    if (spacePressed) {
        auto now = std::chrono::steady_clock::now();
        auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
            now - lastToggleTime).count();

        if (elapsed >= delay_ms) {
            if (!jumpState) {
                WriteJump(FORCE_JUMP_ACTIVE);
                jumpState = true;
                jumpCount++;

                if (jumpCount % 50 == 0) {
                    std::cout << "[Bhop] " << jumpCount << " saltos realizados" << std::endl;
                }
            }
            else {
                WriteJump(FORCE_JUMP_INACTIVE);
                jumpState = false;
            }

            lastToggleTime = now;
        }
    }
    else {
        if (jumpState || was_space_pressed) {
            ResetJump();
        }
    }

    was_space_pressed = spacePressed;
}

int AutoBhop::GetJumpCount() const { return jumpCount; }

void AutoBhop::ResetCounter() { jumpCount = 0; }

bool AutoBhop::IsCS2Active(DWORD cs2_pid) {
    HWND foregroundWindow = GetForegroundWindow();
    if (foregroundWindow == nullptr) return false;

    DWORD windowProcessId;
    GetWindowThreadProcessId(foregroundWindow, &windowProcessId);

    return windowProcessId == cs2_pid;
}

void AutoBhop::WriteJump(uint32_t value) {
    uintptr_t address = base_client.base + dwForceJump;
    WriteProcessMemory(process->handle_,
        (LPVOID)address,
        &value,
        sizeof(uint32_t),
        nullptr);
}

void AutoBhop::ResetJump() {
    if (jumpState) {
        WriteJump(FORCE_JUMP_INACTIVE);
        jumpState = false;
    }
}