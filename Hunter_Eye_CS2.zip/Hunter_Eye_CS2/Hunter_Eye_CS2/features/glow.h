#pragma once
#include "../common.h"
#include "../process.h"
#include "../game.h"
#include "../config.h"

class PlayerGlow {
public:
    PlayerGlow(std::shared_ptr<pProcess> proc, ProcessModule client_module);
    ~PlayerGlow();

    void Run();
    void ApplyGlow(uintptr_t pawn, int team, bool isLocalPlayer);

private:
    std::shared_ptr<pProcess> process;
    ProcessModule client;
};