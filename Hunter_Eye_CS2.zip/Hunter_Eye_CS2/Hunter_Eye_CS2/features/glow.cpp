﻿#include "glow.h"
#include "../offsets.h"
#include <iostream>

PlayerGlow::PlayerGlow(std::shared_ptr<pProcess> proc, ProcessModule client_module)
    : process(proc), client(client_module) {
}

PlayerGlow::~PlayerGlow() {
}

void PlayerGlow::ApplyGlow(uintptr_t pawn, int team, bool isLocalPlayer) {
    if (!pawn || !process) return;

    if (isLocalPlayer) return;

    if (team == g_game.localTeam) {
        if (!g_config.glow_teammates) return;
    }
    else {
        if (!g_config.glow_enemies) return;
    }

    Config::Color glowColor;
    if (team == g_game.localTeam) {
        glowColor = g_config.glow_color_team;
    }
    else {
        glowColor = g_config.glow_color_enemy;
    }

    float colorArray[4];
    colorArray[0] = glowColor.r / 255.0f;  
    colorArray[1] = glowColor.g / 255.0f;  
    colorArray[2] = glowColor.b / 255.0f;  
    colorArray[3] = g_config.glow_alpha / 255.0f; 

    uintptr_t glowAddress = pawn + offsets::m_Glow;

    for (int i = 0; i < 4; i++) {
        process->write<float>(glowAddress + offsets::m_glowColorOverride + (i * 4), colorArray[i]);
    }

    process->write<int>(glowAddress + offsets::m_iGlowType, g_config.glow_type);

    process->write<bool>(glowAddress + offsets::m_bGlowing, true);

}

void PlayerGlow::Run() {
    if (!g_config.glow_enabled) return;
    if (!process || !client.base) return;
    if (!g_game.inGame) return;

    if (offsets::m_Glow == 0) {
        static bool warnedOnce = false;
        if (!warnedOnce) {
            std::cout << "[GLOW ERROR] m_Glow offset is 0! Glow will not work." << std::endl;
            warnedOnce = true;
        }
        return;
    }

    uintptr_t localPlayerController = process->read<uintptr_t>(
        client.base + offsets::dwLocalPlayerController);
    if (!localPlayerController) return;

    uint32_t localPlayerPawn = process->read<uint32_t>(
        localPlayerController + offsets::m_hPlayerPawn);
    if (!localPlayerPawn) return;

    uintptr_t entityList = process->read<uintptr_t>(
        client.base + offsets::dwEntityList);
    if (!entityList) return;

    uintptr_t localListEntry = process->read<uintptr_t>(
        entityList + 0x8 * ((localPlayerPawn & 0x7FFF) >> 9) + 16);
    if (!localListEntry) return;

    uintptr_t localPawn = process->read<uintptr_t>(
        localListEntry + 120 * (localPlayerPawn & 0x1FF));

    for (int i = 1; i < 64; i++) {

        uintptr_t listEntry1 = process->read<uintptr_t>(
            entityList + (8 * (i & 0x7FFF) >> 9) + 16);
        if (!listEntry1) continue;

        uintptr_t playerController = process->read<uintptr_t>(
            listEntry1 + 112     * (i & 0x1FF));
        if (!playerController) continue;

        uint32_t playerPawnHandle = process->read<uint32_t>(
            playerController + offsets::m_hPlayerPawn);
        if (!playerPawnHandle) continue;

        uintptr_t listEntry2 = process->read<uintptr_t>(
            entityList + 0x8 * ((playerPawnHandle & 0x7FFF) >> 9) + 16);
        if (!listEntry2) continue;

        uintptr_t pawn = process->read<uintptr_t>(
            listEntry2 + 120 * (playerPawnHandle & 0x1FF));
        if (!pawn || pawn == localPawn) continue;

        int lifeState = process->read<int>(pawn + offsets::m_lifeState);
 
        if (lifeState != 256 && lifeState != 0) continue;

        int team = process->read<int>(pawn + offsets::m_iTeamNum);

        ApplyGlow(pawn, team, false);
    }
}