#pragma once
#include "../common.h"
#include "../game.h"

namespace radar {
    float deg2rad(float deg);

    void world_to_radar(
        float& outX, float& outY,
        const Vector3& worldPos,
        const Vector3& localPos,
        float localYaw,
        float radarSize,
        float radarZoom
    );

    void draw_background(float centerX, float centerY, float size);
    void draw_local_player(float centerX, float centerY, float yaw);
    void draw_player_dot(float x, float y, bool isEnemy, const std::string& name);
    void render();
}