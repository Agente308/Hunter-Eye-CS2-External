#pragma once
#include "../common.h"
#include "../game.h"

extern bool g_isC4Planted;
extern bool g_wasBombPlanted;
extern float g_bombBlowTime;
extern int g_bombSite;
extern float g_bombTimerLength;
extern std::chrono::steady_clock::time_point g_bombPlantTime;

namespace BombTimer {
    const float TIMER_WIDTH = 200.0f;
    const float TIMER_HEIGHT = 70.0f;
    extern bool bomb_exploded;
    extern bool last_planted_state;
    extern float cached_blow_time;
    extern bool was_counting;

    const char* GetSiteName(int site);
    void UpdateBombStatus();
    float GetRemainingTime();
    void Render();
}