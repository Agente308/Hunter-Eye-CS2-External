#include "fov_changer.h"
#include "../offsets.h"
#include "../config.h"

FOVChanger::FOVChanger(std::shared_ptr<pProcess> proc, ProcessModule client)
    : process(proc), base_client(client), first_success(false) {
    last_message = std::chrono::steady_clock::now();
    last_write = std::chrono::steady_clock::now();
}

void FOVChanger::Run(int localTeam, uintptr_t localPawn) {
    if (!g_config.fov_changer_enabled) {
        first_success = false;
        return;
    }

    if (!localPawn) {
        first_success = false;
        return;
    }

    int health = process->read<int>(localPawn + offsets::m_iHealth);
    if (health <= 0 || health > 100) {
        first_success = false;
        return;
    }

    uintptr_t cameraServices = process->read<uintptr_t>(localPawn + offsets::m_pCameraServices);
    if (!cameraServices) {
        auto now = std::chrono::steady_clock::now();
        if (std::chrono::duration_cast<std::chrono::seconds>(now - last_message).count() >= 5) {
            std::cout << "[FOV] Waiting for valid camera services..." << std::endl;
            last_message = now;
        }
        first_success = false;
        return;
    }

    if (!first_success) {
        std::cout << "[FOV] FOV Changer active! Target FOV: " << g_config.desired_fov << std::endl;
        first_success = true;
    }

    bool isScoped = false;
    if (g_config.fov_ignore_scope && offsets::m_bIsScoped != 0) {
        isScoped = process->read<bool>(localPawn + offsets::m_bIsScoped);
    }

    auto now = std::chrono::steady_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - last_write).count();

    if (!isScoped && elapsed >= WRITE_INTERVAL_MS) {
        uint32_t newFov = static_cast<uint32_t>(g_config.desired_fov);

        WriteProcessMemory(process->handle_,
            (LPVOID)(cameraServices + offsets::m_iFOV),
            &newFov,
            sizeof(uint32_t),
            nullptr);

        last_write = now;
    }
}