#pragma once
#include "../common.h"
#include "../process.h"

class FOVChanger {
private:
    std::shared_ptr<pProcess> process;
    ProcessModule base_client;
    bool first_success;
    std::chrono::steady_clock::time_point last_message;
    std::chrono::steady_clock::time_point last_write;
    static constexpr int WRITE_INTERVAL_MS = 10;

public:
    FOVChanger(std::shared_ptr<pProcess> proc, ProcessModule client);
    void Run(int localTeam, uintptr_t localPawn);
};

extern std::unique_ptr<FOVChanger> g_fov_changer_instance;