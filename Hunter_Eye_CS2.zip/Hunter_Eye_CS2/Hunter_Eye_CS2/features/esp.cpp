﻿#include "esp.h"
#include "../render.h"
#include "../config.h"
#include "../offsets.h"

namespace ESP {
    static const std::vector<std::pair<std::string, std::string>> boneConnections = {
        {"neck_0", "spine_1"},
        {"spine_1", "spine_2"},
        {"spine_2", "pelvis"},
        {"spine_1", "arm_upper_L"},
        {"arm_upper_L", "arm_lower_L"},
        {"arm_lower_L", "hand_L"},
        {"spine_1", "arm_upper_R"},
        {"arm_upper_R", "arm_lower_R"},
        {"arm_lower_R", "hand_R"},
        {"pelvis", "leg_upper_L"},
        {"leg_upper_L", "leg_lower_L"},
        {"leg_lower_L", "ankle_L"},
        {"pelvis", "leg_upper_R"},
        {"leg_upper_R", "leg_lower_R"},
        {"leg_lower_R", "ankle_R"}
    };

    void DrawStyledLine(int x1, int y1, int x2, int y2, COLORREF color, int thickness) {
        if (g_config.esp_line_style == ESP_STYLE_GLOW) {
            render::DrawLineGlow(x1, y1, x2, y2, color, thickness,
                g_config.glow_intensity,
                g_config.glow_blur_radius,
                g_config.glow_alpha_falloff);
        }
        else {
            render::DrawLine(x1, y1, x2, y2, color, thickness);
        }
    }

    void DrawStyledBox(int x, int y, int w, int h, COLORREF color, int thickness) {
        if (g_config.esp_line_style == ESP_STYLE_GLOW) {
            render::DrawBoxGlow(x, y, w, h, color, thickness,
                g_config.glow_intensity,
                g_config.glow_blur_radius,
                g_config.glow_alpha_falloff);
        }
        else {
            render::DrawBox(x, y, w, h, color, thickness);
        }
    }

    void DrawStyledCornerBox(int x, int y, int w, int h, COLORREF color, int cornerLength, int thickness) {
        if (g_config.esp_line_style == ESP_STYLE_GLOW) {
            render::DrawCornerBoxGlow(x, y, w, h, color, cornerLength, thickness,
                g_config.glow_intensity,
                g_config.glow_blur_radius,
                g_config.glow_alpha_falloff);
        }
        else {
            render::DrawCornerBox(x, y, w, h, color, cornerLength, thickness);
        }
    }

    void DrawStyledCircle(int x, int y, int radius, COLORREF color, int thickness) {
        if (g_config.esp_line_style == ESP_STYLE_GLOW) {
            render::DrawCircleGlow(x, y, radius, color, thickness,
                g_config.glow_intensity,
                g_config.glow_blur_radius,
                g_config.glow_alpha_falloff);
        }
        else {
            render::DrawCircle(x, y, radius, color, thickness);
        }
    }

    void Render() {
        if (!g_game.inGame) return;

        const auto& players = g_game.players;
        if (players.empty()) return;

        int screenWidth = g_game.game_bounds.right;
        int screenHeight = g_game.game_bounds.bottom;
        int screenCenterX = screenWidth / 2;
        int screenBottom = screenHeight;

        for (size_t i = 0; i < players.size(); i++) {
            const CPlayer& player = players[i];

            Vector3 screenPos = g_game.world_to_screen(&const_cast<Vector3&>(player.origin));
            if (screenPos.z < 0.01f) continue;

            Vector3 screenHead = g_game.world_to_screen(&const_cast<Vector3&>(player.head));
            if (screenHead.x < -100 || screenHead.x > screenWidth + 100 ||
                screenHead.y < -100 || screenHead.y > screenHeight + 100) continue;

            float height = screenPos.y - screenHead.y;
            if (height <= 0) continue;

            float width = height / 2.4f;
            bool isTeam = (player.team == g_game.localTeam);

            COLORREF boxColor = RGB(
                isTeam ? g_config.box_color_team.r : g_config.box_color_enemy.r,
                isTeam ? g_config.box_color_team.g : g_config.box_color_enemy.g,
                isTeam ? g_config.box_color_team.b : g_config.box_color_enemy.b
            );

            COLORREF skelColor = RGB(
                isTeam ? g_config.skeleton_color_team.r : g_config.skeleton_color_enemy.r,
                isTeam ? g_config.skeleton_color_team.g : g_config.skeleton_color_enemy.g,
                isTeam ? g_config.skeleton_color_team.b : g_config.skeleton_color_enemy.b
            );

            COLORREF headColor = RGB(
                isTeam ? g_config.head_color_team.r : g_config.head_color_enemy.r,
                isTeam ? g_config.head_color_team.g : g_config.head_color_enemy.g,
                isTeam ? g_config.head_color_team.b : g_config.head_color_enemy.b
            );

            COLORREF filledColor = RGB(
                isTeam ? g_config.filled_box_color_team.r : g_config.filled_box_color_enemy.r,
                isTeam ? g_config.filled_box_color_team.g : g_config.filled_box_color_enemy.g,
                isTeam ? g_config.filled_box_color_team.b : g_config.filled_box_color_enemy.b
            );

            int boxX = (int)(screenHead.x - width / 2);
            int boxY = (int)screenHead.y;
            int boxW = (int)width;
            int boxH = (int)height;

            if (g_config.show_filled_box) {
                render::DrawFilledBoxWithAlpha(boxX, boxY, boxW, boxH, filledColor, g_config.filled_box_alpha);
            }

            if (g_config.show_skeleton_esp) {
                for (size_t j = 0; j < boneConnections.size(); j++) {
                    const std::string& fromName = boneConnections[j].first;
                    const std::string& toName = boneConnections[j].second;

                    auto fromIt = player.bones.bonePositions.find(fromName);
                    auto toIt = player.bones.bonePositions.find(toName);

                    if (fromIt != player.bones.bonePositions.end() &&
                        toIt != player.bones.bonePositions.end()) {
                        const Vector3& fromPos = fromIt->second;
                        const Vector3& toPos = toIt->second;

                        if (fromPos.z >= 0.01f && toPos.z >= 0.01f) {
                            DrawStyledLine((int)fromPos.x, (int)fromPos.y,
                                (int)toPos.x, (int)toPos.y,
                                skelColor, g_config.skeleton_thickness);
                        }
                    }
                }
            }

            if (g_config.show_head_tracker) {
                auto headIt = player.bones.bonePositions.find("head");
                if (headIt != player.bones.bonePositions.end()) {
                    const Vector3& headPos = headIt->second;
                    if (headPos.z >= 0.01f) {
                        DrawStyledCircle((int)headPos.x, (int)headPos.y,
                            (int)(width / 5), headColor, 1);
                    }
                }
            }

            if (g_config.show_box_esp) {
                if (g_config.use_corner_box) {
                    DrawStyledCornerBox(boxX, boxY, boxW, boxH, boxColor,
                        (int)(boxW * 0.2f), g_config.box_thickness);
                }
                else {
                    DrawStyledBox(boxX, boxY, boxW, boxH, boxColor, g_config.box_thickness);
                }
            }

            if (g_config.show_health_bar && player.health > 0 && player.health <= 100) {
                int barHeight = (int)(boxH * player.health / 100.0f);

                render::DrawFilledBox(boxX - 5, boxY, 2, boxH, RGB(40, 40, 40));
                render::DrawFilledBox(boxX - 5, boxY + boxH - barHeight, 2, barHeight,
                    RGB(255 - player.health * 2, 55 + player.health * 2, 75));
            }

            if (g_config.show_armor_bar && player.armor > 0 && player.armor <= 100) {
                int barHeight = (int)(boxH * player.armor / 100.0f);

                render::DrawFilledBox(boxX - 9, boxY, 2, boxH, RGB(40, 40, 40));
                render::DrawFilledBox(boxX - 9, boxY + boxH - barHeight, 2, barHeight,
                    RGB(0, 185, 255));
            }

            if (g_config.show_snaplines) {
                DrawStyledLine(screenCenterX, screenBottom,
                    (int)screenHead.x, boxY + boxH,
                    skelColor, g_config.snapline_thickness);
            }

            if (g_config.show_names && !player.name.empty()) {
                render::DrawText(boxX + boxW + 5, boxY, player.name.c_str(),
                    RGB(255, 255, 255), 10);
            }

            if (g_config.show_distance) {
                float distance = g_game.localOrigin.calculate_distance(player.origin);
                char distText[32];
                snprintf(distText, sizeof(distText), "%dm", (int)(distance / 10));
                render::DrawText(boxX + boxW + 5, boxY + 12, distText,
                    RGB(200, 200, 200), 9);
            }
        }
    }
}