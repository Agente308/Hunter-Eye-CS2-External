#include "triggerbot.h"
#include "../offsets.h"
#include "../config.h"

TriggerBot::TriggerBot(std::shared_ptr<pProcess> proc, ProcessModule client)
    : process(proc), base_client(client), hasValidTarget(false) {
    lastShotTime = std::chrono::steady_clock::now();
    targetFoundTime = std::chrono::steady_clock::now();

    weaponNames = {
        {1, "deagle"}, {2, "elite"}, {3, "fiveseven"}, {4, "glock"},
        {7, "ak47"}, {8, "aug"}, {9, "awp"}, {10, "famas"},
        {11, "g3sg1"}, {13, "galilar"}, {14, "m249"}, {16, "m4a4"},
        {17, "mac10"}, {19, "p90"}, {23, "mp5sd"}, {24, "ump45"},
        {25, "xm1014"}, {26, "bizon"}, {27, "mag7"}, {28, "negev"},
        {29, "sawedoff"}, {30, "tec9"}, {32, "p2000"},
        {33, "mp7"}, {34, "mp9"}, {35, "nova"}, {36, "p250"},
        {38, "scar20"}, {39, "sg556"}, {40, "ssg08"}, {60, "m4a1_silencer"},
        {61, "usp_silencer"}, {63, "cz75a"}, {64, "revolver"}
    };
}

void TriggerBot::Run(int localTeam, uintptr_t localPawn) {
    if (!g_triggerbot.enabled) return;
    if (!localPawn) return;

    SHORT keyState = GetAsyncKeyState(g_triggerbot.hotkey);
    bool keyPressed = (keyState & 0x8000) != 0;
    if (!keyPressed) {
        hasValidTarget = false;
        return;
    }

    int health = process->read<int>(localPawn + offsets::m_iHealth);
    if (health <= 0) {
        hasValidTarget = false;
        return;
    }

    DWORD uHandle = process->read<DWORD>(localPawn + offsets::m_iIDEntIndex);
    if (uHandle == static_cast<DWORD>(-1) || uHandle == 0) {
        hasValidTarget = false;
        return;
    }

    uintptr_t entityList = process->read<uintptr_t>(base_client.base + offsets::dwEntityList);
    if (!entityList) return;

    uintptr_t targetPawn = ResolveEntityHandle(entityList, uHandle);
    if (!targetPawn) {
        hasValidTarget = false;
        return;
    }

    if (!CanTrigger(localPawn, targetPawn, localTeam)) {
        hasValidTarget = false;
        return;
    }

    if (!hasValidTarget) {
        targetFoundTime = std::chrono::steady_clock::now();
    }
    hasValidTarget = true;

    auto now = std::chrono::steady_clock::now();
    auto timeSinceLastShot = std::chrono::duration_cast<std::chrono::milliseconds>(
        now - lastShotTime).count();
    auto timeSinceTargetFound = std::chrono::duration_cast<std::chrono::milliseconds>(
        now - targetFoundTime).count();

    if (timeSinceLastShot >= g_triggerbot.shot_duration &&
        timeSinceTargetFound >= g_triggerbot.trigger_delay) {
        ExecuteShot();
    }
}

uintptr_t TriggerBot::ResolveEntityHandle(uintptr_t entityList, DWORD handle) {
    int index = handle & 0x7FFF;
    int segment = index >> 9;
    int entry = index & 0x1FF;

    uintptr_t listSegment = process->read<uintptr_t>(entityList + (0x8 * segment) + 0x10);
    if (!listSegment) return 0;

    uintptr_t entity = process->read<uintptr_t>(listSegment + (112 * entry));
    return entity;
}

bool TriggerBot::CanTrigger(uintptr_t localPawn, uintptr_t targetPawn, int localTeam) {
    int targetHealth = process->read<int>(targetPawn + offsets::m_iHealth);
    if (targetHealth <= 0 || targetHealth > 100) return false;

    if (g_triggerbot.team_check) {
        int targetTeam = process->read<int>(targetPawn + offsets::m_iTeamNum);
        if (localTeam == targetTeam) return false;
    }

    if (!g_triggerbot.ignore_flash && offsets::m_flFlashOverlayAlpha != 0) {
        float flashAlpha = process->read<float>(localPawn + offsets::m_flFlashOverlayAlpha);
        if (flashAlpha > 0.0f) return false;
    }

    if (g_triggerbot.stopped_only && offsets::m_vecAbsVelocity != 0) {
        Vector3 velocity = process->read<Vector3>(localPawn + offsets::m_vecAbsVelocity);
        float speed = velocity.length2d();
        if (speed > 1.0f) return false;
    }

    if (g_triggerbot.scope_only && offsets::m_bIsScoped != 0) {
        bool isScoped = process->read<bool>(localPawn + offsets::m_bIsScoped);
        if (!isScoped) return false;
    }

    return true;
}

void TriggerBot::ExecuteShot() {
    SHORT mouseState = GetAsyncKeyState(VK_LBUTTON);
    if (mouseState & 0x8000) return;

    lastShotTime = std::chrono::steady_clock::now();

    mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
    std::this_thread::sleep_for(std::chrono::milliseconds(25));
    mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
}