﻿#include "radar.h"
#include "../render.h"
#include "../config.h"
#include <vector>

namespace radar {
    float deg2rad(float deg) {
        return deg * (float)(M_PI / 180.0);
    }

    void world_to_radar(
        float& outX, float& outY,
        const Vector3& worldPos,
        const Vector3& localPos,
        float localYaw,
        float radarSize,
        float radarZoom
    ) {
        float deltaX = worldPos.x - localPos.x;
        float deltaY = worldPos.y - localPos.y;

        float distance = sqrtf(deltaX * deltaX + deltaY * deltaY);
        float angleToTarget = atan2f(deltaY, deltaX);
        float localYawRad = deg2rad(localYaw);
        float relativeAngle = angleToTarget - localYawRad;

        float scaledDist = (distance / radarZoom) * (radarSize / 2.0f);
        float maxDist = (radarSize / 2.0f) - 5.0f;

        if (scaledDist > maxDist) {
            scaledDist = maxDist;
        }

        outX = -sinf(relativeAngle) * scaledDist;
        outY = -cosf(relativeAngle) * scaledDist;
    }

    void DrawFilledCircleWithAlpha(int centerX, int centerY, int radius, COLORREF color, int alpha) {
        if (alpha <= 0) return;

        BITMAPINFO bmi = {};
        bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
        bmi.bmiHeader.biWidth = radius * 2;
        bmi.bmiHeader.biHeight = -(radius * 2); 
        bmi.bmiHeader.biPlanes = 1;
        bmi.bmiHeader.biBitCount = 32;
        bmi.bmiHeader.biCompression = BI_RGB;

        void* pBits = nullptr;
        HDC hdcTemp = CreateCompatibleDC(render::hdcBuffer);
        HBITMAP hbmTemp = CreateDIBSection(hdcTemp, &bmi, DIB_RGB_COLORS, &pBits, NULL, 0);

        if (!hbmTemp || !pBits) {
            if (hdcTemp) DeleteDC(hdcTemp);
            if (hbmTemp) DeleteObject(hbmTemp);
            return;
        }

        HBITMAP hbmOldTemp = (HBITMAP)SelectObject(hdcTemp, hbmTemp);

        DWORD* pixels = (DWORD*)pBits;
        int size = radius * 2;

        int r = GetRValue(color);
        int g = GetGValue(color);
        int b = GetBValue(color);

        for (int y = 0; y < size; y++) {
            for (int x = 0; x < size; x++) {
                int dx = x - radius;
                int dy = y - radius;
                float dist = sqrtf((float)(dx * dx + dy * dy));

                if (dist <= radius) {

                    int pixelAlpha = alpha;

                    if (dist > radius - 2.0f) {
                        float edgeFactor = (radius - dist) / 2.0f;
                        pixelAlpha = (int)(alpha * edgeFactor);
                    }

                    int alphaR = (r * pixelAlpha) / 255;
                    int alphaG = (g * pixelAlpha) / 255;
                    int alphaB = (b * pixelAlpha) / 255;

                    pixels[y * size + x] = (pixelAlpha << 24) | (alphaR << 16) | (alphaG << 8) | alphaB;
                }
                else {
                    pixels[y * size + x] = 0x00000000;
                }
            }
        }

        BLENDFUNCTION blend = {};
        blend.BlendOp = AC_SRC_OVER;
        blend.BlendFlags = 0;
        blend.SourceConstantAlpha = 255;
        blend.AlphaFormat = AC_SRC_ALPHA;

        AlphaBlend(render::hdcBuffer,
            centerX - radius, centerY - radius,
            size, size,
            hdcTemp, 0, 0, size, size, blend);

        SelectObject(hdcTemp, hbmOldTemp);
        DeleteObject(hbmTemp);
        DeleteDC(hdcTemp);
    }

    void draw_background(int centerX, int centerY, int size) {
        int radius = size / 2;

        DrawFilledCircleWithAlpha(centerX, centerY, radius, RGB(20, 20, 25), 240);

        render::DrawCircle(centerX, centerY, radius, RGB(60, 60, 80), 3);

        render::DrawLine(
            centerX, centerY - radius + 10,
            centerX, centerY + radius - 10,
            RGB(40, 40, 50), 1
        );
        render::DrawLine(
            centerX - radius + 10, centerY,
            centerX + radius - 10, centerY,
            RGB(40, 40, 50), 1
        );

        for (int i = 1; i <= 3; i++) {
            int innerRadius = (radius * i) / 4;
            render::DrawCircle(centerX, centerY, innerRadius, RGB(35, 35, 45), 1);
        }
    }

    void draw_local_player(int centerX, int centerY, float yaw) {
        int size = 8;

        float rad = deg2rad(-90);

        int p1x = centerX + (int)(sin(rad) * size);
        int p1y = centerY - (int)(cos(rad) * size);

        int p2x = centerX + (int)(sin(rad + 2.5f) * size * 0.6f);
        int p2y = centerY - (int)(cos(rad + 2.5f) * size * 0.6f);

        int p3x = centerX + (int)(sin(rad - 2.5f) * size * 0.6f);
        int p3y = centerY - (int)(cos(rad - 2.5f) * size * 0.6f);

        render::DrawLine(p1x, p1y, p2x, p2y, RGB(0, 200, 255), 2);
        render::DrawLine(p2x, p2y, p3x, p3y, RGB(0, 200, 255), 2);
        render::DrawLine(p3x, p3y, p1x, p1y, RGB(0, 200, 255), 2);

        render::DrawCircle(centerX, centerY, 2, RGB(0, 150, 200), 2);
    }

    void draw_player_dot(
        int x, int y,
        bool isEnemy,
        const std::string& name
    ) {
        int dotSize = 5;
        COLORREF color = isEnemy ? RGB(225, 75, 75) : RGB(75, 175, 75);

        render::DrawCircle(x, y, dotSize, color, 2);

        render::DrawFilledBox(x - dotSize / 2, y - dotSize / 2, dotSize, dotSize, color);

        if (g_config.radar_show_names && !name.empty()) {
            int textWidth = (int)(name.length() * 6);
            int textHeight = 14;

            render::DrawFilledBoxWithAlpha(
                x + dotSize + 1, y - textHeight / 2,
                textWidth + 4, textHeight,
                RGB(20, 20, 25),
                230
            );

            render::DrawText(
                x + dotSize + 3, y - 5,
                name.c_str(),
                RGB(220, 220, 220),
                10
            );
        }
    }

    void render() {

        if (!g_config.show_radar) return;
        if (!g_game.inGame) return;

        int radarSize = (int)g_config.radar_size;
        int centerX = (int)(g_config.radar_x + radarSize / 2.0f);
        int centerY = (int)(g_config.radar_y + radarSize / 2.0f);
        float localYaw = g_game.localViewAngles.y;
        int radius = radarSize / 2;

        draw_background(centerX, centerY, radarSize);

        draw_local_player(centerX, centerY, localYaw);

        const auto& players = g_game.players;
        if (players.empty()) return;

        int maxRadius = radius - 8;

        for (const auto& player : players) {
            float radarX, radarY;

            world_to_radar(
                radarX, radarY,
                player.origin,
                g_game.localOrigin,
                localYaw,
                (float)radarSize,
                g_config.radar_zoom
            );

            int screenX = centerX + (int)radarX;
            int screenY = centerY + (int)radarY;

            float distFromCenter = sqrtf(radarX * radarX + radarY * radarY);
            if (distFromCenter > maxRadius) continue;

            bool isEnemy = (player.team != g_game.localTeam);

            draw_player_dot(
                screenX, screenY,
                isEnemy,
                g_config.radar_show_names ? player.name : ""
            );
        }

     
        
    }
}