#pragma once
#include "../common.h"
#include "../process.h"

class TriggerBot {
private:
    std::shared_ptr<pProcess> process;
    ProcessModule base_client;

    std::chrono::steady_clock::time_point lastShotTime;
    std::chrono::steady_clock::time_point targetFoundTime;
    bool hasValidTarget;

    std::map<short, std::string> weaponNames;

public:
    TriggerBot(std::shared_ptr<pProcess> proc, ProcessModule client);
    void Run(int localTeam, uintptr_t localPawn);

private:
    uintptr_t ResolveEntityHandle(uintptr_t entityList, DWORD handle);
    bool CanTrigger(uintptr_t localPawn, uintptr_t targetPawn, int localTeam);
    void ExecuteShot();
};

extern std::unique_ptr<TriggerBot> g_triggerbot_instance;