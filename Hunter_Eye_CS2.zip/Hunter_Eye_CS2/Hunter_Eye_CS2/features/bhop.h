#pragma once
#include "../common.h"
#include "../process.h"

class AutoBhop {
private:
    std::shared_ptr<pProcess> process;
    ProcessModule base_client;

    uintptr_t dwForceJump;
    bool jumpState;
    int jumpCount;
    std::chrono::steady_clock::time_point lastToggleTime;
    bool was_space_pressed;

    enum Constants {
        FORCE_JUMP_ACTIVE = 65537,
        FORCE_JUMP_INACTIVE = 256
    };

public:
    AutoBhop(std::shared_ptr<pProcess> proc, ProcessModule client, uintptr_t forceJumpOffset);
    void Run(int delay_ms, bool enabled, DWORD cs2_pid);
    int GetJumpCount() const;
    void ResetCounter();

private:
    bool IsCS2Active(DWORD cs2_pid);
    void WriteJump(uint32_t value);
    void ResetJump();
};

extern std::unique_ptr<AutoBhop> g_bhop_instance;