﻿#include "esp.h"
#include "../render_dx11.h"
#include "../config.h"
#include "../offsets.h"

namespace ESP {
    static const std::vector<std::pair<std::string, std::string>> boneConnections = {
        {"neck_0", "spine_1"},
        {"spine_1", "spine_2"},
        {"spine_2", "pelvis"},
        {"spine_1", "arm_upper_L"},
        {"arm_upper_L", "arm_lower_L"},
        {"arm_lower_L", "hand_L"},
        {"spine_1", "arm_upper_R"},
        {"arm_upper_R", "arm_lower_R"},
        {"arm_lower_R", "hand_R"},
        {"pelvis", "leg_upper_L"},
        {"leg_upper_L", "leg_lower_L"},
        {"leg_lower_L", "ankle_L"},
        {"pelvis", "leg_upper_R"},
        {"leg_upper_R", "leg_lower_R"},
        {"leg_lower_R", "ankle_R"}
    };

    void Render() {
        // ═══════════════════════════════════════════════════════════════
        // ✅ RENDERIZAR ESP LIMPIO - SIN DEBUG OVERLAY
        // ═══════════════════════════════════════════════════════════════

        // Verificar si está en partida
        if (!g_game.inGame) return;

        // Copiar jugadores de forma thread-safe
        std::vector<CPlayer> playersCopy;
        {
            std::lock_guard<std::mutex> lock(g_game.playerMutex);
            playersCopy.reserve(g_game.players.size());
            playersCopy = g_game.players;
        }

        // Si no hay jugadores, salir
        if (playersCopy.empty()) return;

        // Obtener dimensiones de pantalla
        int screenWidth = g_game.game_bounds.right;
        int screenHeight = g_game.game_bounds.bottom;
        int screenCenterX = screenWidth / 2;
        int screenBottom = screenHeight;

        // ═══════════════════════════════════════════════════════════════
        // ITERAR SOBRE CADA JUGADOR
        // ═══════════════════════════════════════════════════════════════
        for (const auto& player : playersCopy) {
            // Convertir posición de origen a pantalla
            Vector3 screenPos = g_game.world_to_screen(&const_cast<Vector3&>(player.origin));
            if (screenPos.z < 0.01f) continue;

            // Convertir posición de cabeza a pantalla
            Vector3 screenHead = g_game.world_to_screen(&const_cast<Vector3&>(player.head));

            // Verificar si está fuera de pantalla
            if (screenHead.x < -100 || screenHead.x > screenWidth + 100 ||
                screenHead.y < -100 || screenHead.y > screenHeight + 100) continue;

            // Calcular dimensiones de la caja
            float height = screenPos.y - screenHead.y;
            float width = height / 2.4f;

            // Determinar si es del mismo equipo
            bool isTeam = (player.team == g_game.localTeam);

            // ═══════════════════════════════════════════════════════════
            // COLORES SEGÚN EQUIPO
            // ═══════════════════════════════════════════════════════════
            COLORREF boxColor = RGB(
                isTeam ? g_config.box_color_team.r : g_config.box_color_enemy.r,
                isTeam ? g_config.box_color_team.g : g_config.box_color_enemy.g,
                isTeam ? g_config.box_color_team.b : g_config.box_color_enemy.b
            );

            COLORREF skelColor = RGB(
                isTeam ? g_config.skeleton_color_team.r : g_config.skeleton_color_enemy.r,
                isTeam ? g_config.skeleton_color_team.g : g_config.skeleton_color_enemy.g,
                isTeam ? g_config.skeleton_color_team.b : g_config.skeleton_color_enemy.b
            );

            COLORREF headColor = RGB(
                isTeam ? g_config.head_color_team.r : g_config.head_color_enemy.r,
                isTeam ? g_config.head_color_team.g : g_config.head_color_enemy.g,
                isTeam ? g_config.head_color_team.b : g_config.head_color_enemy.b
            );

            COLORREF filledColor = RGB(
                isTeam ? g_config.filled_box_color_team.r : g_config.filled_box_color_enemy.r,
                isTeam ? g_config.filled_box_color_team.g : g_config.filled_box_color_enemy.g,
                isTeam ? g_config.filled_box_color_team.b : g_config.filled_box_color_enemy.b
            );

            // Calcular coordenadas de la caja
            int boxX = (int)(screenHead.x - width / 2);
            int boxY = (int)screenHead.y;
            int boxW = (int)width;
            int boxH = (int)height;

            // ═══════════════════════════════════════════════════════════
            // PASO 1: FILLED BOX (FONDO SEMITRANSPARENTE)
            // ═══════════════════════════════════════════════════════════
            if (g_config.show_filled_box) {
                RenderDX11::DrawFilledBox(
                    (float)boxX,
                    (float)boxY,
                    (float)boxW,
                    (float)boxH,
                    filledColor,
                    g_config.filled_box_alpha / 255.0f
                );
            }

            // ═══════════════════════════════════════════════════════════
            // PASO 2: SKELETON (ESQUELETO)
            // ═══════════════════════════════════════════════════════════
            if (g_config.show_skeleton_esp) {
                for (const auto& [from, to] : boneConnections) {
                    auto fromIt = player.bones.bonePositions.find(from);
                    auto toIt = player.bones.bonePositions.find(to);

                    if (fromIt != player.bones.bonePositions.end() &&
                        toIt != player.bones.bonePositions.end()) {
                        const auto& fromPos = fromIt->second;
                        const auto& toPos = toIt->second;

                        if (fromPos.z >= 0.01f && toPos.z >= 0.01f) {
                            RenderDX11::DrawLine(
                                fromPos.x, fromPos.y,
                                toPos.x, toPos.y,
                                skelColor,
                                (float)g_config.skeleton_thickness
                            );
                        }
                    }
                }
            }

            // ═══════════════════════════════════════════════════════════
            // PASO 3: HEAD TRACKER (CÍRCULO EN LA CABEZA)
            // ═══════════════════════════════════════════════════════════
            if (g_config.show_head_tracker) {
                auto headIt = player.bones.bonePositions.find("head");
                if (headIt != player.bones.bonePositions.end()) {
                    const auto& headPos = headIt->second;
                    if (headPos.z >= 0.01f) {
                        RenderDX11::DrawCircle(
                            headPos.x,
                            headPos.y,
                            width / 5,
                            headColor,
                            1.0f
                        );
                    }
                }
            }

            // ═══════════════════════════════════════════════════════════
            // PASO 4: BOX (CAJA ALREDEDOR DEL JUGADOR)
            // ═══════════════════════════════════════════════════════════
            if (g_config.show_box_esp) {
                if (g_config.use_corner_box) {
                    // Caja con esquinas
                    float cornerLen = boxW * 0.2f;
                    COLORREF col = boxColor;
                    float thick = (float)g_config.box_thickness;

                    // Esquina superior izquierda
                    RenderDX11::DrawLine((float)boxX, (float)boxY + cornerLen, (float)boxX, (float)boxY, col, thick);
                    RenderDX11::DrawLine((float)boxX, (float)boxY, (float)boxX + cornerLen, (float)boxY, col, thick);

                    // Esquina superior derecha
                    RenderDX11::DrawLine((float)boxX + boxW - cornerLen, (float)boxY, (float)boxX + boxW, (float)boxY, col, thick);
                    RenderDX11::DrawLine((float)boxX + boxW, (float)boxY, (float)boxX + boxW, (float)boxY + cornerLen, col, thick);

                    // Esquina inferior izquierda
                    RenderDX11::DrawLine((float)boxX, (float)boxY + boxH - cornerLen, (float)boxX, (float)boxY + boxH, col, thick);
                    RenderDX11::DrawLine((float)boxX, (float)boxY + boxH, (float)boxX + cornerLen, (float)boxY + boxH, col, thick);

                    // Esquina inferior derecha
                    RenderDX11::DrawLine((float)boxX + boxW - cornerLen, (float)boxY + boxH, (float)boxX + boxW, (float)boxY + boxH, col, thick);
                    RenderDX11::DrawLine((float)boxX + boxW, (float)boxY + boxH - cornerLen, (float)boxX + boxW, (float)boxY + boxH, col, thick);
                }
                else {
                    // Caja normal (rectángulo completo)
                    RenderDX11::DrawBox(
                        (float)boxX,
                        (float)boxY,
                        (float)boxW,
                        (float)boxH,
                        boxColor,
                        (float)g_config.box_thickness
                    );
                }
            }

            // ═══════════════════════════════════════════════════════════
            // PASO 5: HEALTH BAR (BARRA DE VIDA)
            // ═══════════════════════════════════════════════════════════
            if (g_config.show_health_bar) {
                int barHeight = (int)(boxH * player.health / 100.0f);
                RenderDX11::DrawFilledBox(
                    (float)(boxX - 5),
                    (float)(boxY + boxH - barHeight),
                    2.0f,
                    (float)barHeight,
                    RGB(255 - player.health * 2, 55 + player.health * 2, 75),
                    1.0f
                );
            }

            // ═══════════════════════════════════════════════════════════
            // PASO 6: ARMOR BAR (BARRA DE ARMADURA)
            // ═══════════════════════════════════════════════════════════
            if (g_config.show_armor_bar) {
                int barHeight = (int)(boxH * player.armor / 100.0f);
                RenderDX11::DrawFilledBox(
                    (float)(boxX - 9),
                    (float)(boxY + boxH - barHeight),
                    2.0f,
                    (float)barHeight,
                    RGB(0, 185, 255),
                    1.0f
                );
            }

            // ═══════════════════════════════════════════════════════════
            // PASO 7: SNAPLINES (LÍNEAS DESDE EL CENTRO)
            // ═══════════════════════════════════════════════════════════
            if (g_config.show_snaplines) {
                RenderDX11::DrawLine(
                    (float)screenCenterX,
                    (float)screenBottom,
                    screenHead.x,
                    (float)(boxY + boxH),
                    skelColor,
                    (float)g_config.snapline_thickness
                );
            }

            // ═══════════════════════════════════════════════════════════
            // PASO 8: NAME (NOMBRE DEL JUGADOR)
            // ═══════════════════════════════════════════════════════════
            if (g_config.show_names && !player.name.empty()) {
                RenderDX11::DrawText(
                    (float)(boxX + boxW + 5),
                    (float)boxY,
                    player.name.c_str(),
                    RGB(255, 255, 255),
                    10.0f
                );
            }

            // ═══════════════════════════════════════════════════════════
            // PASO 9: DISTANCE (DISTANCIA AL JUGADOR)
            // ═══════════════════════════════════════════════════════════
            if (g_config.show_distance) {
                float distance = g_game.localOrigin.calculate_distance(player.origin);
                std::string distText = std::to_string((int)(distance / 10)) + "m";
                RenderDX11::DrawText(
                    (float)(boxX + boxW + 5),
                    (float)(boxY + 12),
                    distText.c_str(),
                    RGB(200, 200, 200),
                    9.0f
                );
            }
        }
    }
}