#include "bomb_timer.h"
#include "../render_dx11.h"
#include "../config.h"
#include "../offsets.h"

bool g_isC4Planted = false;
bool g_wasBombPlanted = false;
float g_bombBlowTime = 0.0f;
int g_bombSite = -1;
float g_bombTimerLength = 40.0f;
std::chrono::steady_clock::time_point g_bombPlantTime;

namespace BombTimer {
    bool bomb_exploded = false;
    bool last_planted_state = false;
    float cached_blow_time = 0.0f;
    bool was_counting = false;

    const char* GetSiteName(int site) {
        return (site == 0) ? "A" : (site == 1) ? "B" : "?";
    }

    void UpdateBombStatus() {
        if (!g_game.inGame) {
            g_isC4Planted = false;
            g_wasBombPlanted = false;
            g_bombBlowTime = 0.0f;
            g_bombSite = -1;
            bomb_exploded = false;
            last_planted_state = false;
            cached_blow_time = 0.0f;
            was_counting = false;
            return;
        }

        g_wasBombPlanted = g_isC4Planted;
        g_isC4Planted = g_game.isC4Planted;

        if (!g_isC4Planted && last_planted_state) {
            bomb_exploded = false;
            g_bombBlowTime = 0.0f;
            g_bombSite = -1;
            cached_blow_time = 0.0f;
            was_counting = false;
        }

        if (g_isC4Planted && !g_wasBombPlanted) {
            g_bombPlantTime = std::chrono::steady_clock::now();
            g_bombSite = -1;
            bomb_exploded = false;
            cached_blow_time = 0.0f;
            was_counting = false;

            if (offsets::dwPlantedC4 != 0x0) {
                uintptr_t plantedC4Ptr = g_game.process->read<uintptr_t>(
                    g_game.base_client.base + offsets::dwPlantedC4
                );
                if (plantedC4Ptr) {
                    uintptr_t plantedC4 = g_game.process->read<uintptr_t>(plantedC4Ptr);
                    if (plantedC4) {
                        if (offsets::m_nBombSite != 0x0) {
                            g_bombSite = g_game.process->read<int>(plantedC4 + offsets::m_nBombSite);
                        }
                        if (offsets::m_flC4Blow != 0x0) {
                            g_bombBlowTime = g_game.process->read<float>(plantedC4 + offsets::m_flC4Blow);
                        }
                        if (offsets::m_flTimerLength != 0x0) {
                            float timerLen = g_game.process->read<float>(plantedC4 + offsets::m_flTimerLength);
                            if (timerLen > 0 && timerLen <= 60) {
                                g_bombTimerLength = timerLen;
                                cached_blow_time = timerLen;
                                was_counting = true;
                            }
                        }
                    }
                }
            }
        }

        if (g_isC4Planted && !bomb_exploded) {
            float remaining = GetRemainingTime();
            if (remaining > 0) {
                cached_blow_time = remaining;
                was_counting = true;
            }
            else if (remaining <= 0 && was_counting) {
                bomb_exploded = true;
            }
        }

        last_planted_state = g_isC4Planted;
    }

    float GetRemainingTime() {
        if (!g_isC4Planted) {
            return 0.0f;
        }

        auto now = std::chrono::steady_clock::now();
        auto elapsed = std::chrono::duration<float>(now - g_bombPlantTime).count();
        float remaining = g_bombTimerLength - elapsed;

        return (remaining > 0) ? remaining : 0.0f;
    }

    void Render() {
        if (!g_config.show_bomb_timer || !g_game.inGame) return;

        float x = g_config.bomb_timer_x;
        float y = g_config.bomb_timer_y;

        RenderDX11::DrawFilledBox(x, y, TIMER_WIDTH, TIMER_HEIGHT, RGB(25, 25, 25), 1.0f);
        RenderDX11::DrawBox(x, y, TIMER_WIDTH, TIMER_HEIGHT, RGB(255, 140, 0), 3.0f);

        RenderDX11::DrawText(x + 10, y + 8, "C4 STATUS", RGB(255, 165, 0), 12.0f);

        if (!g_isC4Planted) {
            RenderDX11::DrawText(x + 10, y + 35, "Not Planted", RGB(100, 100, 100), 14.0f);
        }
        else if (bomb_exploded) {
            RenderDX11::DrawText(x + 50, y + 35, "EXPLODED!", RGB(255, 0, 0), 16.0f);
        }
        else {
            float remaining = GetRemainingTime();

            if (g_bombSite >= 0) {
                char siteText[32];
                snprintf(siteText, sizeof(siteText), "Site: %s", GetSiteName(g_bombSite));
                RenderDX11::DrawText(x + 10, y + 30, siteText, RGB(255, 200, 0), 11.0f);
            }

            char timerText[32];
            int secs = (int)remaining;
            int ms = (int)((remaining - secs) * 100);
            snprintf(timerText, sizeof(timerText), "%02d.%02d", secs, ms);

            COLORREF timerColor;
            if (remaining > 10) {
                timerColor = RGB(0, 255, 100);
            }
            else if (remaining > 5) {
                timerColor = RGB(255, 200, 0);
            }
            else {
                timerColor = RGB(255, 50, 50);
            }

            RenderDX11::DrawText(x + 60, y + 45, timerText, timerColor, 18.0f);
        }
    }
}