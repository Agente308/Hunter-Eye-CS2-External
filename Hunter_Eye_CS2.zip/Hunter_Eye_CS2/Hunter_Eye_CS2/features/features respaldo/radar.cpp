#include "radar.h"
#include "../render_dx11.h"
#include "../config.h"
#include "../imgui.h"

namespace radar {
    float deg2rad(float deg) {
        return deg * (float)(M_PI / 180.0);
    }

    void world_to_radar(
        float& outX, float& outY,
        const Vector3& worldPos,
        const Vector3& localPos,
        float localYaw,
        float radarSize,
        float radarZoom
    ) {
        float deltaX = worldPos.x - localPos.x;
        float deltaY = worldPos.y - localPos.y;

        float distance = sqrtf(deltaX * deltaX + deltaY * deltaY);

        float angleToTarget = atan2f(deltaY, deltaX);

        float localYawRad = deg2rad(localYaw);
        float relativeAngle = angleToTarget - localYawRad;

        float scaledDist = (distance / radarZoom) * (radarSize / 2.0f);

        float maxDist = (radarSize / 2.0f) - 5.0f;
        if (scaledDist > maxDist) {
            scaledDist = maxDist;
        }

        outX = -sinf(relativeAngle) * scaledDist;
        outY = -cosf(relativeAngle) * scaledDist;
    }

    void draw_background(float centerX, float centerY, float size) {
        float radius = size / 2.0f;

        ImDrawList* draw_list = ImGui::GetBackgroundDrawList();

        draw_list->AddCircleFilled(ImVec2(centerX, centerY), radius, IM_COL32(20, 20, 25, 240), 64);
        draw_list->AddCircle(ImVec2(centerX, centerY), radius, IM_COL32(60, 60, 80, 255), 64, 2.0f);

        draw_list->AddLine(ImVec2(centerX, centerY - radius + 5), ImVec2(centerX, centerY + radius - 5), IM_COL32(40, 40, 50, 255), 1.0f);
        draw_list->AddLine(ImVec2(centerX - radius + 5, centerY), ImVec2(centerX + radius - 5, centerY), IM_COL32(40, 40, 50, 255), 1.0f);
    }

    void draw_local_player(float centerX, float centerY, float yaw) {
        ImDrawList* draw_list = ImGui::GetBackgroundDrawList();
        float size = 8.0f;

        ImVec2 p1(centerX, centerY - size);
        ImVec2 p2(centerX - size * 0.6f, centerY + size * 0.5f);
        ImVec2 p3(centerX + size * 0.6f, centerY + size * 0.5f);

        draw_list->AddTriangleFilled(p1, p2, p3, IM_COL32(0, 200, 255, 255));
        draw_list->AddTriangle(p1, p2, p3, IM_COL32(0, 150, 200, 255), 1.5f);
    }

    void draw_player_dot(
        float x, float y,
        bool isEnemy,
        const std::string& name
    ) {
        ImDrawList* draw_list = ImGui::GetBackgroundDrawList();
        float dotSize = 5.0f;
        ImU32 color = isEnemy ? IM_COL32(225, 75, 75, 255) : IM_COL32(75, 175, 75, 255);

        draw_list->AddCircleFilled(ImVec2(x, y), dotSize, color, 16);

        if (g_config.radar_show_names && !name.empty()) {
            float textWidth = name.length() * 6.0f;
            draw_list->AddRectFilled(
                ImVec2(x + dotSize + 1, y - 7),
                ImVec2(x + dotSize + textWidth + 5, y + 7),
                IM_COL32(20, 20, 25, 230)
            );
            draw_list->AddText(ImVec2(x + dotSize + 3, y - 5), IM_COL32(220, 220, 220, 255), name.c_str());
        }
    }

    void render() {
        if (!g_config.show_radar) return;
        if (!g_game.inGame) return;

        float radarSize = g_config.radar_size;
        float centerX = g_config.radar_x + radarSize / 2.0f;
        float centerY = g_config.radar_y + radarSize / 2.0f;
        float localYaw = g_game.localViewAngles.y;

        draw_background(centerX, centerY, radarSize);
        draw_local_player(centerX, centerY, localYaw);

        std::vector<CPlayer> playersCopy;
        {
            std::lock_guard<std::mutex> lock(g_game.playerMutex);
            playersCopy = g_game.players;
        }

        for (auto& player : playersCopy) {
            float radarX, radarY;

            world_to_radar(
                radarX, radarY,
                player.origin,
                g_game.localOrigin,
                localYaw,
                radarSize,
                g_config.radar_zoom
            );

            float screenX = centerX + radarX;
            float screenY = centerY + radarY;
            float distFromCenter = sqrtf(radarX * radarX + radarY * radarY);
            float maxRadius = (radarSize / 2.0f) - 8.0f;
            if (distFromCenter > maxRadius) continue;

            bool isEnemy = (player.team != g_game.localTeam);

            draw_player_dot(
                screenX, screenY,
                isEnemy,
                g_config.radar_show_names ? player.name : ""
            );
        }
    }
}