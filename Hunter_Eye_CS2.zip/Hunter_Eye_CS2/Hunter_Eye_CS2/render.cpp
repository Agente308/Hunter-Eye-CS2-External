﻿#include "render.h"
#include <cmath>
#include <algorithm>

#undef min
#undef max

namespace render {
    HDC hdcBuffer = NULL;
    HBITMAP hbmBuffer = NULL;
    HBITMAP hbmOld = NULL;

    struct BitmapCache {
        HDC hdc;
        HBITMAP bitmap;
        HBITMAP oldBitmap;
        int width;
        int height;
        void* bits;
    };

    static BitmapCache g_tempBitmapCache = { NULL, NULL, NULL, 0, 0, nullptr };

    void Init(HWND hWnd, int width, int height) {
        HDC hdc = GetDC(hWnd);
        hdcBuffer = CreateCompatibleDC(hdc);
        hbmBuffer = CreateCompatibleBitmap(hdc, width, height);
        hbmOld = (HBITMAP)SelectObject(hdcBuffer, hbmBuffer);
        SetGraphicsMode(hdcBuffer, GM_ADVANCED);
        ReleaseDC(hWnd, hdc);
    }

    void ClearBuffer() {
        if (!hdcBuffer) return;

        BITMAP bm;
        GetObject(hbmBuffer, sizeof(bm), &bm);

        PatBlt(hdcBuffer, 0, 0, bm.bmWidth, bm.bmHeight, BLACKNESS);
    }

    void Cleanup() {
        if (g_tempBitmapCache.hdc) {
            if (g_tempBitmapCache.oldBitmap) {
                SelectObject(g_tempBitmapCache.hdc, g_tempBitmapCache.oldBitmap);
            }
            if (g_tempBitmapCache.bitmap) {
                DeleteObject(g_tempBitmapCache.bitmap);
            }
            DeleteDC(g_tempBitmapCache.hdc);
            g_tempBitmapCache = { NULL, NULL, NULL, 0, 0, nullptr };
        }

        if (hdcBuffer) {
            if (hbmOld) SelectObject(hdcBuffer, hbmOld);
            DeleteDC(hdcBuffer);
        }
        if (hbmBuffer) DeleteObject(hbmBuffer);
    }

    void DrawLine(int x, int y, int x2, int y2, COLORREF color, int thickness) {
        HPEN pen = CreatePen(PS_SOLID, thickness, color);
        HPEN oldPen = (HPEN)SelectObject(hdcBuffer, pen);
        MoveToEx(hdcBuffer, x, y, NULL);
        LineTo(hdcBuffer, x2, y2);
        SelectObject(hdcBuffer, oldPen);
        DeleteObject(pen);
    }

    void DrawBox(int x, int y, int w, int h, COLORREF color, int thickness) {
        HBRUSH oldBrush = (HBRUSH)SelectObject(hdcBuffer, GetStockObject(NULL_BRUSH));
        HPEN pen = CreatePen(PS_SOLID, thickness, color);
        HPEN oldPen = (HPEN)SelectObject(hdcBuffer, pen);
        Rectangle(hdcBuffer, x, y, x + w, y + h);
        SelectObject(hdcBuffer, oldPen);
        SelectObject(hdcBuffer, oldBrush);
        DeleteObject(pen);
    }

    void DrawCornerBox(int x, int y, int w, int h, COLORREF color, int cornerLength, int thickness) {
        HPEN pen = CreatePen(PS_SOLID, thickness, color);
        HPEN oldPen = (HPEN)SelectObject(hdcBuffer, pen);

        MoveToEx(hdcBuffer, x, y + cornerLength, NULL);
        LineTo(hdcBuffer, x, y);
        LineTo(hdcBuffer, x + cornerLength, y);

        MoveToEx(hdcBuffer, x + w - cornerLength, y, NULL);
        LineTo(hdcBuffer, x + w, y);
        LineTo(hdcBuffer, x + w, y + cornerLength);

        MoveToEx(hdcBuffer, x, y + h - cornerLength, NULL);
        LineTo(hdcBuffer, x, y + h);
        LineTo(hdcBuffer, x + cornerLength, y + h);

        MoveToEx(hdcBuffer, x + w - cornerLength, y + h, NULL);
        LineTo(hdcBuffer, x + w, y + h);
        LineTo(hdcBuffer, x + w, y + h - cornerLength);

        SelectObject(hdcBuffer, oldPen);
        DeleteObject(pen);
    }

    void DrawFilledBox(int x, int y, int w, int h, COLORREF color) {
        HBRUSH brush = CreateSolidBrush(color);
        RECT rect = { x, y, x + w, y + h };
        FillRect(hdcBuffer, &rect, brush);
        DeleteObject(brush);
    }

    void DrawFilledBoxWithAlpha(int x, int y, int w, int h, COLORREF color, int alpha) {
        if (alpha <= 0) return;
        if (alpha >= 255) {
            DrawFilledBox(x, y, w, h, color);
            return;
        }

        int r = GetRValue(color);
        int g = GetGValue(color);
        int b = GetBValue(color);

        BITMAPINFO bmi = {};
        bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
        bmi.bmiHeader.biWidth = w;
        bmi.bmiHeader.biHeight = -h;
        bmi.bmiHeader.biPlanes = 1;
        bmi.bmiHeader.biBitCount = 32;
        bmi.bmiHeader.biCompression = BI_RGB;

        void* pBits = nullptr;
        HDC hdcTemp = CreateCompatibleDC(hdcBuffer);
        HBITMAP hbmTemp = CreateDIBSection(hdcTemp, &bmi, DIB_RGB_COLORS, &pBits, NULL, 0);

        if (!hbmTemp || !pBits) {
            if (hdcTemp) DeleteDC(hdcTemp);
            if (hbmTemp) DeleteObject(hbmTemp);
            DrawFilledBox(x, y, w, h, color);
            return;
        }

        HBITMAP hbmOldTemp = (HBITMAP)SelectObject(hdcTemp, hbmTemp);

        DWORD* pixels = (DWORD*)pBits;
        int pixelCount = w * h;
        int alphaR = (r * alpha) / 255;
        int alphaG = (g * alpha) / 255;
        int alphaB = (b * alpha) / 255;
        DWORD argbColor = (alpha << 24) | (alphaR << 16) | (alphaG << 8) | alphaB;

        for (int i = 0; i < pixelCount; i++) {
            pixels[i] = argbColor;
        }

        BLENDFUNCTION blend = {};
        blend.BlendOp = AC_SRC_OVER;
        blend.BlendFlags = 0;
        blend.SourceConstantAlpha = 255;
        blend.AlphaFormat = AC_SRC_ALPHA;

        AlphaBlend(hdcBuffer, x, y, w, h, hdcTemp, 0, 0, w, h, blend);

        SelectObject(hdcTemp, hbmOldTemp);
        DeleteObject(hbmTemp);
        DeleteDC(hdcTemp);
    }

    void DrawText(int x, int y, const char* text, COLORREF color, int size) {
        LOGFONT lf = {};
        lf.lfHeight = -size;
        lf.lfWeight = FW_NORMAL;
        lf.lfQuality = ANTIALIASED_QUALITY;
        wcscpy_s(lf.lfFaceName, LF_FACESIZE, L"Verdana");

        HFONT font = CreateFontIndirect(&lf);
        HFONT oldFont = (HFONT)SelectObject(hdcBuffer, font);

        SetBkMode(hdcBuffer, TRANSPARENT);
        SetTextColor(hdcBuffer, color);

        int len = MultiByteToWideChar(CP_UTF8, 0, text, -1, NULL, 0);
        if (len > 0) {
            wchar_t* wtext = new wchar_t[len];
            MultiByteToWideChar(CP_UTF8, 0, text, -1, wtext, len);
            TextOutW(hdcBuffer, x, y, wtext, len - 1);
            delete[] wtext;
        }

        SelectObject(hdcBuffer, oldFont);
        DeleteObject(font);
    }

    void DrawCircle(int x, int y, int radius, COLORREF color, int thickness) {
        HPEN pen = CreatePen(PS_SOLID, thickness, color);
        HPEN oldPen = (HPEN)SelectObject(hdcBuffer, pen);
        HBRUSH oldBrush = (HBRUSH)SelectObject(hdcBuffer, GetStockObject(NULL_BRUSH));

        Ellipse(hdcBuffer, x - radius, y - radius, x + radius, y + radius);

        SelectObject(hdcBuffer, oldBrush);
        SelectObject(hdcBuffer, oldPen);
        DeleteObject(pen);
    }

    void RenderTextWithBackground(int x, int y, const char* text, COLORREF textColor, COLORREF bgColor, int size, int paddingX, int paddingY) {
        LOGFONT lf = {};
        lf.lfHeight = -size;
        lf.lfWeight = FW_NORMAL;
        lf.lfQuality = ANTIALIASED_QUALITY;
        wcscpy_s(lf.lfFaceName, LF_FACESIZE, L"Verdana");

        HFONT font = CreateFontIndirect(&lf);
        HFONT oldFont = (HFONT)SelectObject(hdcBuffer, font);

        int len = MultiByteToWideChar(CP_UTF8, 0, text, -1, NULL, 0);
        if (len > 0) {
            wchar_t* wtext = new wchar_t[len];
            MultiByteToWideChar(CP_UTF8, 0, text, -1, wtext, len);

            SIZE textSize;
            GetTextExtentPoint32W(hdcBuffer, wtext, len - 1, &textSize);

            HBRUSH bgBrush = CreateSolidBrush(bgColor);
            RECT bgRect = {
                x - paddingX,
                y - paddingY,
                x + textSize.cx + paddingX,
                y + textSize.cy + paddingY
            };
            FillRect(hdcBuffer, &bgRect, bgBrush);
            DeleteObject(bgBrush);

            SetBkMode(hdcBuffer, TRANSPARENT);
            SetTextColor(hdcBuffer, textColor);
            TextOutW(hdcBuffer, x, y, wtext, len - 1);

            delete[] wtext;
        }

        SelectObject(hdcBuffer, oldFont);
        DeleteObject(font);
    }

    inline int MinInt(int a, int b) { return (a < b) ? a : b; }
    inline int MaxInt(int a, int b) { return (a > b) ? a : b; }

    bool GetOrCreateTempBitmap(int width, int height, BitmapCache& cache) {

        if (cache.hdc && cache.width >= width && cache.height >= height) {

            PatBlt(cache.hdc, 0, 0, cache.width, cache.height, BLACKNESS);
            return true;
        }

        if (cache.hdc) {
            if (cache.oldBitmap) SelectObject(cache.hdc, cache.oldBitmap);
            if (cache.bitmap) DeleteObject(cache.bitmap);
            DeleteDC(cache.hdc);
        }

        BITMAPINFO bmi = {};
        bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
        bmi.bmiHeader.biWidth = width;
        bmi.bmiHeader.biHeight = -height;
        bmi.bmiHeader.biPlanes = 1;
        bmi.bmiHeader.biBitCount = 32;
        bmi.bmiHeader.biCompression = BI_RGB;

        cache.hdc = CreateCompatibleDC(hdcBuffer);
        if (!cache.hdc) return false;

        cache.bitmap = CreateDIBSection(cache.hdc, &bmi, DIB_RGB_COLORS, &cache.bits, NULL, 0);
        if (!cache.bitmap) {
            DeleteDC(cache.hdc);
            cache.hdc = NULL;
            return false;
        }

        cache.oldBitmap = (HBITMAP)SelectObject(cache.hdc, cache.bitmap);
        cache.width = width;
        cache.height = height;

        return true;
    }

    void DrawLineGlowLayer(int x1, int y1, int x2, int y2, COLORREF color, int thickness, int alpha) {
        if (alpha <= 0) return;

        int minX = MinInt(x1, x2) - thickness - 2;
        int maxX = MaxInt(x1, x2) + thickness + 2;
        int minY = MinInt(y1, y2) - thickness - 2;
        int maxY = MaxInt(y1, y2) + thickness + 2;
        int w = maxX - minX + 1;
        int h = maxY - minY + 1;

        if (w <= 0 || h <= 0 || w > 4000 || h > 4000) return;

        if (!GetOrCreateTempBitmap(w, h, g_tempBitmapCache)) {

            DrawLine(x1, y1, x2, y2, color, thickness);
            return;
        }

        int r = GetRValue(color);
        int g = GetGValue(color);
        int b = GetBValue(color);
        COLORREF solidColor = RGB(r, g, b);

        HPEN pen = CreatePen(PS_SOLID, thickness, solidColor);
        HPEN oldPen = (HPEN)SelectObject(g_tempBitmapCache.hdc, pen);

        MoveToEx(g_tempBitmapCache.hdc, x1 - minX, y1 - minY, NULL);
        LineTo(g_tempBitmapCache.hdc, x2 - minX, y2 - minY);

        SelectObject(g_tempBitmapCache.hdc, oldPen);
        DeleteObject(pen);

        DWORD* pixels = (DWORD*)g_tempBitmapCache.bits;
        int pixelCount = w * h;

        for (int i = 0; i < pixelCount; i++) {
            if (pixels[i] != 0) {
                int pr = (pixels[i] >> 16) & 0xFF;
                int pg = (pixels[i] >> 8) & 0xFF;
                int pb = pixels[i] & 0xFF;

                pr = (pr * alpha) / 255;
                pg = (pg * alpha) / 255;
                pb = (pb * alpha) / 255;

                pixels[i] = (alpha << 24) | (pr << 16) | (pg << 8) | pb;
            }
        }

        BLENDFUNCTION blend = {};
        blend.BlendOp = AC_SRC_OVER;
        blend.BlendFlags = 0;
        blend.SourceConstantAlpha = 255;
        blend.AlphaFormat = AC_SRC_ALPHA;

        AlphaBlend(hdcBuffer, minX, minY, w, h, g_tempBitmapCache.hdc, 0, 0, w, h, blend);
    }

    void DrawLineGlow(int x, int y, int x2, int y2, COLORREF color, int thickness,
        int glowIntensity, int blurRadius, float alphaFalloff) {

        if (!hdcBuffer) return;

        int r = GetRValue(color);
        int g = GetGValue(color);
        int b = GetBValue(color);

        glowIntensity = MinInt(glowIntensity, 5); 

        for (int i = glowIntensity; i > 0; i--) {

            float factor = 1.0f - ((float)i / (float)(glowIntensity + 1));

            float rawAlpha = powf(factor, alphaFalloff);
            int alpha = (int)(rawAlpha * 180.0f); 

            int layerThickness = thickness + ((glowIntensity - i + 1) * blurRadius) / glowIntensity;

            int glowR = (r + (255 - r) * factor * 3 / 10);
            if (glowR > 255) glowR = 255;

            int glowG = (g + (255 - g) * factor * 3 / 10);
            if (glowG > 255) glowG = 255;

            int glowB = (b + (255 - b) * factor * 3 / 10);
            if (glowB > 255) glowB = 255;

            COLORREF layerColor = RGB(glowR, glowG, glowB);

            DrawLineGlowLayer(x, y, x2, y2, layerColor, layerThickness, alpha);
        }

        DrawLine(x, y, x2, y2, color, thickness);
    }

    void DrawBoxGlow(int x, int y, int w, int h, COLORREF color, int thickness,
        int glowIntensity, int blurRadius, float alphaFalloff) {

        DrawLineGlow(x, y, x + w, y, color, thickness, glowIntensity, blurRadius, alphaFalloff);         
        DrawLineGlow(x + w, y, x + w, y + h, color, thickness, glowIntensity, blurRadius, alphaFalloff);  
        DrawLineGlow(x + w, y + h, x, y + h, color, thickness, glowIntensity, blurRadius, alphaFalloff);  
        DrawLineGlow(x, y + h, x, y, color, thickness, glowIntensity, blurRadius, alphaFalloff);         
    }

    void DrawCornerBoxGlow(int x, int y, int w, int h, COLORREF color, int cornerLength,
        int thickness, int glowIntensity, int blurRadius, float alphaFalloff) {

        DrawLineGlow(x, y + cornerLength, x, y, color, thickness, glowIntensity, blurRadius, alphaFalloff);
        DrawLineGlow(x, y, x + cornerLength, y, color, thickness, glowIntensity, blurRadius, alphaFalloff);

        DrawLineGlow(x + w - cornerLength, y, x + w, y, color, thickness, glowIntensity, blurRadius, alphaFalloff);
        DrawLineGlow(x + w, y, x + w, y + cornerLength, color, thickness, glowIntensity, blurRadius, alphaFalloff);

        DrawLineGlow(x, y + h - cornerLength, x, y + h, color, thickness, glowIntensity, blurRadius, alphaFalloff);
        DrawLineGlow(x, y + h, x + cornerLength, y + h, color, thickness, glowIntensity, blurRadius, alphaFalloff);

        DrawLineGlow(x + w - cornerLength, y + h, x + w, y + h, color, thickness, glowIntensity, blurRadius, alphaFalloff);
        DrawLineGlow(x + w, y + h, x + w, y + h - cornerLength, color, thickness, glowIntensity, blurRadius, alphaFalloff);
    }

    void DrawCircleGlow(int x, int y, int radius, COLORREF color, int thickness,
        int glowIntensity, int blurRadius, float alphaFalloff) {

        if (!hdcBuffer) return;

        int r = GetRValue(color);
        int g = GetGValue(color);
        int b = GetBValue(color);

        for (int i = glowIntensity; i > 0; i--) {
            float factor = 1.0f - ((float)i / (float)(glowIntensity + 1));
            float rawAlpha = powf(factor, alphaFalloff);
            int alpha = (int)(rawAlpha * 180.0f);

            int layerRadius = radius + ((glowIntensity - i + 1) * blurRadius) / glowIntensity;
            int layerThickness = MaxInt(1, thickness + i / 2);

            int glowR = (r + (255 - r) * factor * 3 / 10);
            if (glowR > 255) glowR = 255;

            int glowG = (g + (255 - g) * factor * 3 / 10);
            if (glowG > 255) glowG = 255;

            int glowB = (b + (255 - b) * factor * 3 / 10);
            if (glowB > 255) glowB = 255;

            COLORREF layerColor = RGB(glowR, glowG, glowB);

            int size = (layerRadius + layerThickness) * 2 + 10;
            BITMAPINFO bmi = {};
            bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
            bmi.bmiHeader.biWidth = size;
            bmi.bmiHeader.biHeight = -size;
            bmi.bmiHeader.biPlanes = 1;
            bmi.bmiHeader.biBitCount = 32;
            bmi.bmiHeader.biCompression = BI_RGB;

            void* pBits = nullptr;
            HDC hdcTemp = CreateCompatibleDC(hdcBuffer);
            HBITMAP hbmTemp = CreateDIBSection(hdcTemp, &bmi, DIB_RGB_COLORS, &pBits, NULL, 0);

            if (!hbmTemp || !pBits) {
                if (hdcTemp) DeleteDC(hdcTemp);
                if (hbmTemp) DeleteObject(hbmTemp);
                continue;
            }

            HBITMAP hbmOldTemp = (HBITMAP)SelectObject(hdcTemp, hbmTemp);
            DWORD* pixels = (DWORD*)pBits;
            memset(pixels, 0, size * size * 4);

            HPEN pen = CreatePen(PS_SOLID, layerThickness, layerColor);
            HPEN oldPen = (HPEN)SelectObject(hdcTemp, pen);
            HBRUSH oldBrush = (HBRUSH)SelectObject(hdcTemp, GetStockObject(NULL_BRUSH));

            int centerX = size / 2;
            int centerY = size / 2;
            Ellipse(hdcTemp, centerX - layerRadius, centerY - layerRadius,
                centerX + layerRadius, centerY + layerRadius);

            SelectObject(hdcTemp, oldBrush);
            SelectObject(hdcTemp, oldPen);
            DeleteObject(pen);

            for (int j = 0; j < size * size; j++) {
                if (pixels[j] != 0) {
                    int pr = (pixels[j] >> 16) & 0xFF;
                    int pg = (pixels[j] >> 8) & 0xFF;
                    int pb = pixels[j] & 0xFF;

                    pr = (pr * alpha) / 255;
                    pg = (pg * alpha) / 255;
                    pb = (pb * alpha) / 255;

                    pixels[j] = (alpha << 24) | (pr << 16) | (pg << 8) | pb;
                }
            }

            BLENDFUNCTION blend = {};
            blend.BlendOp = AC_SRC_OVER;
            blend.BlendFlags = 0;
            blend.SourceConstantAlpha = 255;
            blend.AlphaFormat = AC_SRC_ALPHA;

            AlphaBlend(hdcBuffer, x - size / 2, y - size / 2, size, size, hdcTemp, 0, 0, size, size, blend);

            SelectObject(hdcTemp, hbmOldTemp);
            DeleteObject(hbmTemp);
            DeleteDC(hdcTemp);
        }

        DrawCircle(x, y, radius, color, thickness);
    }

}