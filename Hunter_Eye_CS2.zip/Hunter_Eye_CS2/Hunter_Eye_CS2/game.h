#pragma once
#include "common.h"
#include "process.h"

struct CBones {
    std::map<std::string, Vector3> bonePositions;
};

struct CPlayer {
    uintptr_t entity;
    int team;
    uintptr_t pCSPlayerPawn;
    uintptr_t gameSceneNode;
    uintptr_t boneArray;
    int health;
    int armor;
    bool is_spotted;
    std::string name;
    Vector3 origin;
    Vector3 head;
    CBones bones;
};

struct EntityCache {
    uintptr_t entity_list = 0;
    std::chrono::steady_clock::time_point last_update;
    static constexpr int CACHE_MS = 100;

    bool is_valid() const;
    void update(uintptr_t value);
};

class CGame {
public:
    std::shared_ptr<pProcess> process;
    ProcessModule base_client;
    ProcessModule base_engine;
    RECT game_bounds;
    int buildNumber;
    bool inGame = false;
    Vector3 localOrigin;
    int localTeam;
    std::vector<CPlayer> players;
    std::mutex playerMutex;
    bool isC4Planted = false;
    Vector2 localViewAngles;

    void init();
    bool loop();
    Vector3 world_to_screen(Vector3* v);

private:
    EntityCache entity_cache;
    view_matrix_t view_matrix;

    void ReadBones(CPlayer& player);
};

extern CGame g_game;