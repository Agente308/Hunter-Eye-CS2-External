﻿#pragma once
#include "common.h"

namespace render {
    extern HDC hdcBuffer;
    extern HBITMAP hbmBuffer;
    extern HBITMAP hbmOld;

    void Init(HWND hWnd, int width, int height);
    void Cleanup();
    void ClearBuffer(); 

    void DrawLine(int x, int y, int x2, int y2, COLORREF color, int thickness = 1);
    void DrawBox(int x, int y, int w, int h, COLORREF color, int thickness = 1);
    void DrawCornerBox(int x, int y, int w, int h, COLORREF color, int cornerLength = 10, int thickness = 2);
    void DrawFilledBox(int x, int y, int w, int h, COLORREF color);
    void DrawFilledBoxWithAlpha(int x, int y, int w, int h, COLORREF color, int alpha);
    void DrawText(int x, int y, const char* text, COLORREF color, int size = 12);
    void DrawCircle(int x, int y, int radius, COLORREF color, int thickness = 1);
    void RenderTextWithBackground(int x, int y, const char* text, COLORREF textColor, COLORREF bgColor, int size, int paddingX = 3, int paddingY = 1);

    void DrawLineGlow(int x, int y, int x2, int y2, COLORREF color, int thickness = 1,
        int glowIntensity = 5, int blurRadius = 12, float alphaFalloff = 0.6f);

    void DrawBoxGlow(int x, int y, int w, int h, COLORREF color, int thickness = 1,
        int glowIntensity = 5, int blurRadius = 12, float alphaFalloff = 0.6f);

    void DrawCornerBoxGlow(int x, int y, int w, int h, COLORREF color, int cornerLength = 10,
        int thickness = 2, int glowIntensity = 5, int blurRadius = 12, float alphaFalloff = 0.6f);

    void DrawCircleGlow(int x, int y, int radius, COLORREF color, int thickness = 1,
        int glowIntensity = 5, int blurRadius = 12, float alphaFalloff = 0.6f);
}