﻿#pragma once

// ═══════════════════════════════════════════════════════════════
// Windows Headers
// ═══════════════════════════════════════════════════════════════
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winternl.h>
#include <TlHelp32.h>
#include <Psapi.h>

// ═══════════════════════════════════════════════════════════════
// STL Headers
// ═══════════════════════════════════════════════════════════════
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <unordered_map>
#include <array>
#include <thread>
#include <mutex>
#include <atomic>
#include <chrono>
#include <algorithm>
#include <cmath>
#include <functional>
#include <queue>
#include <condition_variable>
#include <memory>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

typedef NTSTATUS(NTAPI* pNtReadVirtualMemory)(
    HANDLE ProcessHandle,
    PVOID BaseAddress,
    PVOID Buffer,
    SIZE_T BufferSize,          
    PSIZE_T NumberOfBytesRead  
    );

#define NT_SUCCESS(Status) (((NTSTATUS)(Status)) >= 0)

typedef NTSTATUS(NTAPI* pNtWriteVirtualMemory)(
    HANDLE ProcessHandle,
    PVOID BaseAddress,
    PVOID Buffer,
    SIZE_T NumberOfBytesToWrite,
    PSIZE_T NumberOfBytesWritten
    );

typedef NTSTATUS(NTAPI* pNtWriteVirtualMemory)(
    HANDLE ProcessHandle,
    PVOID BaseAddress,
    PVOID Buffer,
    SIZE_T NumberOfBytesToWrite,
    PSIZE_T NumberOfBytesWritten
    );

struct ProcessModule {
    uintptr_t base;
    DWORD size;
};

struct Vector2 {
    float x, y;
    Vector2() : x(0), y(0) {}
    Vector2(float _x, float _y) : x(_x), y(_y) {}
};

struct Vector3 {
    float x, y, z;
    Vector3() : x(0), y(0), z(0) {}
    Vector3(float _x, float _y, float _z) : x(_x), y(_y), z(_z) {}

    Vector3 operator-(const Vector3& other) const {
        return Vector3(x - other.x, y - other.y, z - other.z);
    }

    float calculate_distance(const Vector3& other) const {
        float dx = x - other.x;
        float dy = y - other.y;
        float dz = z - other.z;
        return std::sqrt(dx * dx + dy * dy + dz * dz);
    }

    float length2d() const {
        return std::sqrt(x * x + y * y);
    }

    float length() const {
        return std::sqrt(x * x + y * y + z * z);
    }
};

struct Matrix4x4 {
    float matrix[4][4];
};

using view_matrix_t = Matrix4x4;

struct Bones {
    std::map<std::string, Vector3> bonePositions;
};

struct CPlayer;

struct TriggerConfig {
    bool enabled = false;
    int delay_min = 10;
    int delay_max = 30;
    int trigger_delay = 20;
    int shot_duration = 100;
    bool ignore_teammates = true;
    bool require_key = false;
    int activation_key = VK_XBUTTON1;
    int hotkey = VK_XBUTTON1;
    bool burst_mode = false;
    int burst_count = 3;
    int burst_delay = 50;
    bool scope_only = false;
    bool ignore_flash = true;
    bool stopped_only = false;
    bool team_check = true;
};

struct Keybinds {
    int esp_toggle = VK_F1;
    int radar_toggle = VK_F2;
    int bhop_toggle = VK_SPACE;
    int triggerbot_toggle = VK_F4;
    int bomb_toggle = VK_F3;
};

extern std::map<std::string, int> boneMap;

extern std::atomic<bool> g_running;
extern TriggerConfig g_triggerbot;
extern Keybinds g_keybinds;