﻿#include "input_hooks.h"
#include "imgui.h"
#include "imgui_menu.h"
#include <iostream>

namespace InputHooks {
    bool g_MenuOpen = false;
    HWND g_GameWindow = nullptr;
    HWND g_OverlayWindow = nullptr;

    bool Initialize(HWND gameWindow, HWND overlayWindow) {
        g_GameWindow = gameWindow;
        g_OverlayWindow = overlayWindow;
        std::cout << "[+] Input system initialized" << std::endl;
        return true;
    }

    void Shutdown() {
    }

    void Update() {

        if (g_MenuOpen) {
            ClipCursor(NULL);

            static int showCount = ShowCursor(TRUE);
            if (showCount < 0) {
                while (ShowCursor(TRUE) < 0) {}
            }
        }
    }

    void SetMenuState(bool open) {
        g_MenuOpen = open;

        if (!g_OverlayWindow) {
            std::cout << "[INPUT] ERROR: Overlay window is null!" << std::endl;
            return;
        }

        std::cout << "[INPUT] " << (open ? ">> Opening menu" : ">> Closing menu") << std::endl;

        LONG exStyle = GetWindowLong(g_OverlayWindow, GWL_EXSTYLE);

        if (open) {
            exStyle &= ~WS_EX_TRANSPARENT;
            SetWindowLong(g_OverlayWindow, GWL_EXSTYLE, exStyle);

            SetWindowPos(
                g_OverlayWindow,
                HWND_TOPMOST,
                0, 0, 0, 0,
                SWP_NOMOVE | SWP_NOSIZE | SWP_FRAMECHANGED | SWP_SHOWWINDOW
            );

            ClipCursor(NULL);

            SetForegroundWindow(g_OverlayWindow);
            SetFocus(g_OverlayWindow);

            ImGuiIO& io = ImGui::GetIO();
            io.ConfigFlags &= ~ImGuiConfigFlags_NoMouse;
            io.WantCaptureMouse = true;
            io.WantCaptureKeyboard = true;

            std::cout << "[INPUT] >>  Menu opened successfully" << std::endl;
        }
        else {
            exStyle |= WS_EX_TRANSPARENT;
            SetWindowLong(g_OverlayWindow, GWL_EXSTYLE, exStyle);

            SetWindowPos(
                g_OverlayWindow,
                HWND_TOPMOST,
                0, 0, 0, 0,
                SWP_NOMOVE | SWP_NOSIZE | SWP_FRAMECHANGED
            );

            ImGuiIO& io = ImGui::GetIO();
            io.WantCaptureMouse = false;
            io.WantCaptureKeyboard = false;

            if (g_GameWindow) {
                SetForegroundWindow(g_GameWindow);
                SetFocus(g_GameWindow);
                std::cout << "[INPUT] >>  Focus returned to game" << std::endl;
            }

            std::cout << "[INPUT] >>  Menu closed successfully" << std::endl;
        }
    }
}