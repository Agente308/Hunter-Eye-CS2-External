﻿#include "game.h"
#include "offsets.h"
#include "config.h"

CGame g_game;

bool EntityCache::is_valid() const {
    auto now = std::chrono::steady_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - last_update).count();
    return elapsed < CACHE_MS && entity_list != 0;
}

void EntityCache::update(uintptr_t value) {
    entity_list = value;
    last_update = std::chrono::steady_clock::now();
}

void CGame::init() {
    std::cout << "[*] Waiting for cs2.exe..." << std::endl;
    process = std::make_shared<pProcess>();

    while (!process->AttachProcess("cs2.exe")) {
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }

    std::cout << "[+] Attached to CS2 (PID: " << process->pid_ << ")" << std::endl;

    std::cout << "[*] Loading modules..." << std::endl;
    do {
        base_client = process->GetModule("client.dll");
        base_engine = process->GetModule("engine2.dll");

        if (base_client.base == 0 || base_engine.base == 0) {
            std::this_thread::sleep_for(std::chrono::seconds(1));
            std::cout << "[*] Waiting for modules to load..." << std::endl;
        }
    } while (base_client.base == 0 || base_engine.base == 0);

    std::cout << "[+] client.dll base: 0x" << std::hex << base_client.base << std::dec << std::endl;
    std::cout << "[+] engine2.dll base: 0x" << std::hex << base_engine.base << std::dec << std::endl;

    GetClientRect(process->hwnd_, &game_bounds);
    buildNumber = process->read<int>(base_engine.base + offsets::dwBuildNumber);
    std::cout << "[+] Game build: " << buildNumber << std::endl;
}

bool CGame::loop() {
    try {
        DWORD exitCode = 0;
        if (process && process->handle_) {
            if (GetExitCodeProcess(process->handle_, &exitCode)) {
                if (exitCode != STILL_ACTIVE) {
                    return false;
                }
            }
        }
        else {
            return false;
        }

        if (offsets::dwLocalPlayerController == 0x0) {
            return false;
        }

        inGame = false;

        uintptr_t localPlayer = process->read<uintptr_t>(base_client.base + offsets::dwLocalPlayerController);
        if (!localPlayer) return true;

        uint32_t localPlayerPawn = process->read<uint32_t>(localPlayer + offsets::m_hPlayerPawn);
        if (!localPlayerPawn) return true;

        uintptr_t entity_list;
        if (entity_cache.is_valid()) {
            entity_list = entity_cache.entity_list;
        }
        else {
            entity_list = process->read<uintptr_t>(base_client.base + offsets::dwEntityList);
            if (!entity_list) return true;
            entity_cache.update(entity_list);
        }

        uintptr_t localList_entry2 = process->read<uintptr_t>(entity_list + 0x8 * ((localPlayerPawn & 0x7FFF) >> 9) + 16);
        uintptr_t localpCSPlayerPawn = process->read<uintptr_t>(localList_entry2 + 112 * (localPlayerPawn & 0x1FF));
        if (!localpCSPlayerPawn) return true;

        view_matrix = process->read<view_matrix_t>(base_client.base + offsets::dwViewMatrix);
        localTeam = process->read<int>(localPlayer + offsets::m_iTeamNum);
        localOrigin = process->read<Vector3>(localpCSPlayerPawn + offsets::m_vOldOrigin);
        inGame = true;

        if (offsets::m_angEyeAngles != 0) {
            localViewAngles = process->read<Vector2>(localpCSPlayerPawn + offsets::m_angEyeAngles);
        }
        else {
            localViewAngles = process->read<Vector2>(localpCSPlayerPawn + 0x1564);
        }

        isC4Planted = false;
        if (offsets::dwPlantedC4 != 0x0) {
            uintptr_t plantedC4Ptr = process->read<uintptr_t>(base_client.base + offsets::dwPlantedC4);
            if (plantedC4Ptr) {
                uintptr_t plantedC4 = process->read<uintptr_t>(plantedC4Ptr);
                if (plantedC4) {
                    if (offsets::m_flTimerLength != 0x0) {
                        float timerLength = process->read<float>(plantedC4 + offsets::m_flTimerLength);
                        if (timerLength > 0.0f && timerLength <= 60.0f) {
                            if (offsets::m_flC4Blow != 0x0) {
                                float blowTime = process->read<float>(plantedC4 + offsets::m_flC4Blow);
                                if (blowTime > 0.0f) {
                                    isC4Planted = true;
                                }
                            }
                            else {
                                isC4Planted = true;
                            }
                        }
                    }
                }
            }
        }

        std::vector<CPlayer> list;
        list.reserve(64);

        for (int playerIndex = 1; playerIndex <= 64; playerIndex++) {
            uintptr_t list_entry = process->read<uintptr_t>(entity_list + (8 * (playerIndex & 0x7FFF) >> 9) + 16);
            if (!list_entry) continue;

            CPlayer player;
            player.entity = process->read<uintptr_t>(list_entry + 112 * (playerIndex & 0x1FF));
            if (!player.entity) continue;

            player.team = process->read<int>(player.entity + offsets::m_iTeamNum);

            bool isTeammate = (player.team == localTeam);
            bool isEnemy = (player.team != localTeam);

            if (g_config.ignore_teammates && isTeammate) continue;
            if (g_config.ignore_enemies && isEnemy) continue;
            if (!g_config.team_esp && player.team == localTeam) continue;

            uint32_t playerPawn = process->read<uint32_t>(player.entity + offsets::m_hPlayerPawn);
            uintptr_t list_entry2 = process->read<uintptr_t>(entity_list + 0x8 * ((playerPawn & 0x7FFF) >> 9) + 16);
            if (!list_entry2) continue;

            player.pCSPlayerPawn = process->read<uintptr_t>(list_entry2 + 112 * (playerPawn & 0x1FF));
            if (!player.pCSPlayerPawn) continue;

            if (player.pCSPlayerPawn == localpCSPlayerPawn) continue;

            player.health = process->read<int>(player.pCSPlayerPawn + offsets::m_iHealth);
            if (player.health <= 0 || player.health > 100) continue;

            player.armor = process->read<int>(player.pCSPlayerPawn + offsets::m_ArmorValue);
            player.origin = process->read<Vector3>(player.pCSPlayerPawn + offsets::m_vOldOrigin);

            if (player.origin.x == 0 && player.origin.y == 0) continue;

            if (player.origin.x == localOrigin.x && player.origin.y == localOrigin.y && player.origin.z == localOrigin.z)
                continue;

            if (g_config.render_distance > 0 && (localOrigin - player.origin).length2d() > g_config.render_distance)
                continue;

            player.head = Vector3(player.origin.x, player.origin.y, player.origin.z + 75.f);
            player.is_spotted = process->read<bool>(player.pCSPlayerPawn + offsets::m_entitySpottedState + 0x8);

            if (g_config.show_names) {
                uintptr_t handle = process->read<uintptr_t>(player.pCSPlayerPawn + offsets::m_hController);
                int index = handle & 0x7FFF;
                int segment = index >> 9;
                int entry = index & 0x1FF;

                uintptr_t controllerListSegment = process->read<uintptr_t>(entity_list + 0x8 * segment + 0x10);
                uintptr_t controller = process->read<uintptr_t>(controllerListSegment + 112 * entry);

                if (controller) {
                    char buffer[128] = {};
                    process->read_raw(controller + offsets::m_iszPlayerName, buffer, sizeof(buffer) - 1);
                    buffer[sizeof(buffer) - 1] = '\0';
                    player.name = buffer;
                }
            }

            if (g_config.show_skeleton_esp || g_config.show_head_tracker) {
                player.gameSceneNode = process->read<uintptr_t>(player.pCSPlayerPawn + offsets::m_pGameSceneNode);
                player.boneArray = process->read<uintptr_t>(player.gameSceneNode + 0x210);
                ReadBones(player);
            }

            list.push_back(player);
        }

        {
            std::lock_guard<std::mutex> lock(playerMutex);
            players = std::move(list);
        }

        return true;

    }
    catch (const std::exception& e) {
        return false;
    }
    catch (...) {
        return false;
    }
}

Vector3 CGame::world_to_screen(Vector3* v) {
    float _x = view_matrix.matrix[0][0] * v->x + view_matrix.matrix[0][1] * v->y + view_matrix.matrix[0][2] * v->z + view_matrix.matrix[0][3];
    float _y = view_matrix.matrix[1][0] * v->x + view_matrix.matrix[1][1] * v->y + view_matrix.matrix[1][2] * v->z + view_matrix.matrix[1][3];
    float w = view_matrix.matrix[3][0] * v->x + view_matrix.matrix[3][1] * v->y + view_matrix.matrix[3][2] * v->z + view_matrix.matrix[3][3];

    if (w < 0.01f) return Vector3(0, 0, -1);

    float inv_w = 1.f / w;
    _x *= inv_w;
    _y *= inv_w;

    float x = game_bounds.right * 0.5f;
    float y = game_bounds.bottom * 0.5f;

    x += 0.5f * _x * game_bounds.right + 0.5f;
    y -= 0.5f * _y * game_bounds.bottom + 0.5f;

    return Vector3(x, y, w);
}

void CGame::ReadBones(CPlayer& player) {
    std::vector<std::string> bonesToRead;

    if (g_config.show_skeleton_esp) {
        bonesToRead = { "head", "neck_0", "spine_1", "spine_2", "pelvis",
                      "arm_upper_L", "arm_lower_L", "hand_L",
                      "arm_upper_R", "arm_lower_R", "hand_R",
                      "leg_upper_L", "leg_lower_L", "ankle_L",
                      "leg_upper_R", "leg_lower_R", "ankle_R" };
    }
    else if (g_config.show_head_tracker) {
        bonesToRead = { "head" };
    }

    for (const auto& boneName : bonesToRead) {
        if (boneMap.count(boneName)) {
            int boneIndex = boneMap[boneName];
            uintptr_t boneAddress = player.boneArray + boneIndex * 32;
            Vector3 bonePosition = process->read<Vector3>(boneAddress);
            player.bones.bonePositions[boneName] = world_to_screen(&bonePosition);
        }
    }
}