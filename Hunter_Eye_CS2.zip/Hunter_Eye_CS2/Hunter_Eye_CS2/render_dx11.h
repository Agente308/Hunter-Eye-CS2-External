#pragma once
#include "common.h"
#include <d3d11.h>
#include <dxgi.h>

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")

namespace RenderDX11 {
    extern ID3D11Device* g_pd3dDevice;
    extern ID3D11DeviceContext* g_pd3dDeviceContext;
    extern IDXGISwapChain* g_pSwapChain;
    extern ID3D11RenderTargetView* g_mainRenderTargetView;

    bool Initialize(HWND hwnd, int width, int height);
    void Cleanup();
    void BeginFrame();
    void EndFrame();
    void Present();

    void DrawLine(float x1, float y1, float x2, float y2, COLORREF color, float thickness = 1.0f);
    void DrawBox(float x, float y, float w, float h, COLORREF color, float thickness = 1.0f);
    void DrawFilledBox(float x, float y, float w, float h, COLORREF color, float alpha = 1.0f);
    void DrawCircle(float x, float y, float radius, COLORREF color, float thickness = 1.0f);
    void DrawText(float x, float y, const char* text, COLORREF color, float size = 12.0f);
}