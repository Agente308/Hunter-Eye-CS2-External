#pragma once
#include "common.h"

namespace offsets {
    extern uintptr_t dwLocalPlayerController;
    extern uintptr_t dwLocalPlayerPawn;
    extern uintptr_t dwEntityList;
    extern uintptr_t dwViewMatrix;
    extern uintptr_t dwBuildNumber;
    extern uintptr_t dwPlantedC4;
    extern uintptr_t dwForceJump;

    extern uintptr_t m_hPlayerPawn;
    extern uintptr_t m_iHealth;
    extern uintptr_t m_ArmorValue;
    extern uintptr_t m_iTeamNum;
    extern uintptr_t m_vOldOrigin;
    extern uintptr_t m_pGameSceneNode;
    extern uintptr_t m_vecAbsOrigin;
    extern uintptr_t m_iszPlayerName;
    extern uintptr_t m_entitySpottedState;
    extern uintptr_t m_hController;
    extern uintptr_t m_angEyeAngles;

    extern uintptr_t m_flFlashOverlayAlpha;
    extern uintptr_t m_bIsScoped;
    extern uintptr_t m_vecAbsVelocity;
    extern uintptr_t m_iIDEntIndex;

    extern uintptr_t m_pCameraServices;
    extern uintptr_t m_iFOV;
    extern uintptr_t m_iFOVStart;

    extern uintptr_t m_flC4Blow;
    extern uintptr_t m_nBombSite;
    extern uintptr_t m_flTimerLength;
    extern uintptr_t m_bBombPlanted;
    extern uintptr_t m_flNextBeep;

    extern uintptr_t m_Glow;  
    extern uintptr_t m_glowColorOverride;  
    extern uintptr_t m_iGlowType;  
    extern uintptr_t m_bGlowing;  
    extern uintptr_t m_lifeState;  

    uintptr_t findValueInJson(const std::string& json, const std::string& key);
    bool LoadFromURL();
}