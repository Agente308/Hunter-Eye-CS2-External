﻿#include "process.h"

pProcess::pProcess() : pid_(0), handle_(NULL), hwnd_(NULL), base_client_{ 0, 0 } {
    std::cout << "[DEBUG] Initializing pProcess..." << std::endl;

    HMODULE ntdll = GetModuleHandleA("ntdll.dll");
    if (ntdll) {
        pfnNtReadVirtualMemory = (pNtReadVirtualMemory)GetProcAddress(ntdll, "NtReadVirtualMemory");
        if (pfnNtReadVirtualMemory) {
            std::cout << "[DEBUG] NtReadVirtualMemory found at: " << (void*)pfnNtReadVirtualMemory << std::endl;
        }
        else {
            std::cout << "[DEBUG] Failed to get NtReadVirtualMemory!" << std::endl;
        }

        pfnNtWriteVirtualMemory = (pNtWriteVirtualMemory)GetProcAddress(ntdll, "NtWriteVirtualMemory");
        if (pfnNtWriteVirtualMemory) {
            std::cout << "[DEBUG] NtWriteVirtualMemory found at: " << (void*)pfnNtWriteVirtualMemory << std::endl;
        }
        else {
            std::cout << "[DEBUG] Failed to get NtWriteVirtualMemory!" << std::endl;
        }
    }
    else {
        std::cout << "[DEBUG] Failed to get ntdll.dll handle!" << std::endl;
    }
}

pProcess::~pProcess() {
    if (handle_ && handle_ != INVALID_HANDLE_VALUE) {
        CloseHandle(handle_);
    }
}

bool pProcess::AttachProcess(const char* process_name) {
    pid_ = FindProcessIdByProcessName(process_name);
    if (!pid_) return false;

    handle_ = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_OPERATION | PROCESS_VM_READ | PROCESS_VM_WRITE, FALSE, pid_);
    if (!handle_ || handle_ == INVALID_HANDLE_VALUE) return false;

    HMODULE modules[256];
    MODULEINFO module_info;
    DWORD needed;

    if (!EnumProcessModulesEx(handle_, modules, sizeof(modules), &needed, LIST_MODULES_64BIT))
        return false;

    base_client_.base = (uintptr_t)modules[0];

    if (!GetModuleInformation(handle_, modules[0], &module_info, sizeof(module_info)))
        return false;

    base_client_.size = module_info.SizeOfImage;
    hwnd_ = GetWindowHandleFromProcessId(pid_);

    return true;
}

ProcessModule pProcess::GetModule(const char* module_name) {
    if (!handle_ || handle_ == INVALID_HANDLE_VALUE)
        return { 0, 0 };

    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid_);
    if (snap == INVALID_HANDLE_VALUE)
        return { 0, 0 };

    MODULEENTRY32W entry = {};
    entry.dwSize = sizeof(MODULEENTRY32W);

    std::wstring wideModule;
    int len = MultiByteToWideChar(CP_UTF8, 0, module_name, -1, nullptr, 0);
    if (len > 0) {
        wideModule.resize(len);
        MultiByteToWideChar(CP_UTF8, 0, module_name, -1, &wideModule[0], len);
    }

    ProcessModule result = { 0, 0 };

    if (Module32FirstW(snap, &entry)) {
        do {
            if (!wcscmp(entry.szModule, wideModule.c_str())) {
                result.base = (uintptr_t)entry.modBaseAddr;
                result.size = entry.dwSize;
                break;
            }
        } while (Module32NextW(snap, &entry));
    }

    CloseHandle(snap);
    return result;
}

bool pProcess::UpdateHWND() {
    hwnd_ = GetWindowHandleFromProcessId(pid_);
    return hwnd_ != nullptr;
}

bool pProcess::read_raw(uintptr_t address, void* buffer, size_t size) {
    if (!pfnNtReadVirtualMemory || !handle_) {
        std::cout << "[ERROR] read_raw failed: pfnNtReadVirtualMemory="
            << (void*)pfnNtReadVirtualMemory << " handle_=" << (void*)handle_ << std::endl;
        return false;
    }

    SIZE_T bytesRead = 0;
    NTSTATUS ntStatus = pfnNtReadVirtualMemory(
        handle_,
        (PVOID)address,
        buffer,
        size,
        &bytesRead
    );

    bool success = NT_SUCCESS(ntStatus) && (bytesRead == size);

    if (!success) {
        static int errorCount = 0;
        if (errorCount++ < 5) {
            std::cout << "[ERROR] read_raw failed at address 0x" << std::hex << address << std::dec
                << " status=0x" << std::hex << ntStatus << std::dec << std::endl;
        }
    }

    return success;
}

bool pProcess::write_raw(uintptr_t address, const void* buffer, size_t size) {
    if (!pfnNtWriteVirtualMemory || !handle_) {
        std::cout << "[ERROR] write_raw failed: pfnNtWriteVirtualMemory="
            << (void*)pfnNtWriteVirtualMemory << " handle_=" << (void*)handle_ << std::endl;
        return false;
    }

    SIZE_T bytesWritten = 0;
    NTSTATUS ntStatus = pfnNtWriteVirtualMemory(
        handle_,
        (PVOID)address,
        (PVOID)buffer,
        size,
        &bytesWritten
    );

    bool success = NT_SUCCESS(ntStatus) && (bytesWritten == size);

    if (!success) {
        static int errorCount = 0;
        if (errorCount++ < 5) {
            std::cout << "[ERROR] write_raw failed at address 0x" << std::hex << address << std::dec
                << " status=0x" << std::hex << ntStatus << std::dec
                << " bytesWritten=" << bytesWritten << "/" << size << std::endl;
        }
    }

    return success;
}

DWORD pProcess::FindProcessIdByProcessName(const char* name) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE)
        return 0;

    PROCESSENTRY32W entry = {};
    entry.dwSize = sizeof(entry);

    std::wstring wideName;
    int len = MultiByteToWideChar(CP_UTF8, 0, name, -1, nullptr, 0);
    if (len > 0) {
        wideName.resize(len);
        MultiByteToWideChar(CP_UTF8, 0, name, -1, &wideName[0], len);
    }

    DWORD pid = 0;
    if (Process32FirstW(snap, &entry)) {
        do {
            if (!wcscmp(entry.szExeFile, wideName.c_str())) {
                pid = entry.th32ProcessID;
                break;
            }
        } while (Process32NextW(snap, &entry));
    }

    CloseHandle(snap);
    return pid;
}

HWND pProcess::GetWindowHandleFromProcessId(DWORD pid) {
    HWND hwnd = NULL;
    do {
        hwnd = FindWindowEx(NULL, hwnd, NULL, NULL);
        if (!hwnd) break;

        DWORD windowPid = 0;
        GetWindowThreadProcessId(hwnd, &windowPid);

        if (windowPid == pid && IsWindowVisible(hwnd)) {
            TCHAR title[MAX_PATH];
            GetWindowText(hwnd, title, MAX_PATH);
            if (title[0] != '\0') return hwnd;
        }
    } while (hwnd != NULL);

    return NULL;
}