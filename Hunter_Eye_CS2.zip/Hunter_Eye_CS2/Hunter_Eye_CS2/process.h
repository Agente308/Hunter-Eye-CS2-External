﻿#pragma once
#include "common.h"
#include <array>

struct BatchReadRequest {
    uintptr_t address;
    void* buffer;
    size_t size;
};

class pProcess {
public:
    DWORD pid_;
    HANDLE handle_;
    HWND hwnd_;
    ProcessModule base_client_;

private:
    pNtReadVirtualMemory pfnNtReadVirtualMemory;
    pNtWriteVirtualMemory pfnNtWriteVirtualMemory; 

    struct ReadCache {
        std::unordered_map<uintptr_t, std::pair<std::chrono::steady_clock::time_point, std::vector<uint8_t>>> cacheData;
        std::mutex cacheMutex;
        std::chrono::milliseconds cacheLifetime{ 100 }; 
    } readCache_;

public:
    pProcess();
    ~pProcess();

    bool AttachProcess(const char* process_name);
    ProcessModule GetModule(const char* module_name);
    bool UpdateHWND();

    template<class T>
    T read(uintptr_t address, bool useCache = false) {
        T buffer{};

        if (useCache) {
            auto cached = GetFromCache(address, sizeof(T));
            if (!cached.empty()) {
                memcpy(&buffer, cached.data(), sizeof(T));
                return buffer;
            }
        }

        if (pfnNtReadVirtualMemory && handle_) {
            SIZE_T bytesRead = 0;
            NTSTATUS status = pfnNtReadVirtualMemory(
                handle_,
                (PVOID)address,
                &buffer,
                sizeof(T),
                &bytesRead
            );

            if (NT_SUCCESS(status) && useCache && bytesRead == sizeof(T)) {
                CacheData(address, &buffer, sizeof(T));
            }
        }
        return buffer;
    }

    template<class T>
    bool write(uintptr_t address, T value) {
        if (!pfnNtWriteVirtualMemory || !handle_)
            return false;

        SIZE_T bytesWritten = 0;
        NTSTATUS status = pfnNtWriteVirtualMemory(
            handle_,
            (PVOID)address,
            &value,
            sizeof(T),
            &bytesWritten
        );

        return NT_SUCCESS(status) && (bytesWritten == sizeof(T));
    }

    bool read_raw(uintptr_t address, void* buffer, size_t size);

    bool write_raw(uintptr_t address, const void* buffer, size_t size);

    template<typename T>
    bool read_batch(const std::vector<uintptr_t>& addresses, std::vector<T>& results) {
        if (!pfnNtReadVirtualMemory || !handle_ || addresses.empty())
            return false;

        results.resize(addresses.size());

        for (size_t i = 0; i < addresses.size(); i++) {
            SIZE_T bytesRead = 0;
            pfnNtReadVirtualMemory(
                handle_,
                (PVOID)addresses[i],
                &results[i],
                sizeof(T),
                &bytesRead
            );
        }
        return true;
    }

    bool read_batch_variable(const std::vector<BatchReadRequest>& requests) {
        if (!pfnNtReadVirtualMemory || !handle_ || requests.empty())
            return false;

        for (const auto& req : requests) {
            SIZE_T bytesRead = 0;
            pfnNtReadVirtualMemory(
                handle_,
                (PVOID)req.address,
                req.buffer,
                req.size,
                &bytesRead
            );
        }
        return true;
    }

    bool read_bulk(uintptr_t startAddress, void* buffer, size_t totalSize) {
        if (!pfnNtReadVirtualMemory || !handle_)
            return false;

        SIZE_T bytesRead = 0;
        NTSTATUS status = pfnNtReadVirtualMemory(
            handle_,
            (PVOID)startAddress,
            buffer,
            totalSize,
            &bytesRead
        );

        return NT_SUCCESS(status) && (bytesRead == totalSize);
    }

    void ClearCache() {
        std::lock_guard<std::mutex> lock(readCache_.cacheMutex);
        readCache_.cacheData.clear();
    }

    void SetCacheLifetime(int milliseconds) {
        readCache_.cacheLifetime = std::chrono::milliseconds(milliseconds);
    }

private:
    DWORD FindProcessIdByProcessName(const char* name);
    HWND GetWindowHandleFromProcessId(DWORD pid);

    std::vector<uint8_t> GetFromCache(uintptr_t address, size_t size) {
        std::lock_guard<std::mutex> lock(readCache_.cacheMutex);

        auto it = readCache_.cacheData.find(address);
        if (it != readCache_.cacheData.end()) {
            auto now = std::chrono::steady_clock::now();
            auto age = std::chrono::duration_cast<std::chrono::milliseconds>(now - it->second.first);

            if (age.count() < readCache_.cacheLifetime.count()) {
                return it->second.second;
            }
            else {
                readCache_.cacheData.erase(it);
            }
        }

        return {};
    }

    void CacheData(uintptr_t address, const void* data, size_t size) {
        std::lock_guard<std::mutex> lock(readCache_.cacheMutex);

        std::vector<uint8_t> buffer(size);
        memcpy(buffer.data(), data, size);

        readCache_.cacheData[address] = { std::chrono::steady_clock::now(), buffer };

        if (readCache_.cacheData.size() > 1000) {
            auto oldest = readCache_.cacheData.begin();
            auto now = std::chrono::steady_clock::now();

            for (auto it = readCache_.cacheData.begin(); it != readCache_.cacheData.end(); ++it) {
                if (it->second.first < oldest->second.first) {
                    oldest = it;
                }
            }
            readCache_.cacheData.erase(oldest);
        }
    }
};