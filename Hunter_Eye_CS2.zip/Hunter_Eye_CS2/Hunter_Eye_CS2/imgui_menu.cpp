﻿#include "imgui_menu.h"
#include "common.h"
#include "config.h"
#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"

namespace ImGuiMenu {
    bool g_ShowMenu = false;
    bool g_Initialized = false;

    static int* g_CurrentlyBinding = nullptr;
    static std::string g_BindingName = "";

    const char* VKToString(int vk) {
        switch (vk) {
        case VK_F1: return "F1";
        case VK_F2: return "F2";
        case VK_F3: return "F3";
        case VK_F4: return "F4";
        case VK_F5: return "F5";
        case VK_F6: return "F6";
        case VK_F7: return "F7";
        case VK_F8: return "F8";
        case VK_F9: return "F9";
        case VK_F10: return "F10";
        case VK_F11: return "F11";
        case VK_F12: return "F12";
        case VK_INSERT: return "INSERT";
        case VK_DELETE: return "DELETE";
        case VK_HOME: return "HOME";
        case VK_END: return "END";
        case VK_PRIOR: return "PAGE UP";
        case VK_NEXT: return "PAGE DOWN";
        case VK_LBUTTON: return "MOUSE1";
        case VK_RBUTTON: return "MOUSE2";
        case VK_MBUTTON: return "MOUSE3";
        case VK_XBUTTON1: return "MOUSE4";
        case VK_XBUTTON2: return "MOUSE5";
        case VK_SHIFT: return "SHIFT";
        case VK_CONTROL: return "CTRL";
        case VK_MENU: return "ALT";
        case VK_SPACE: return "SPACE";
        case VK_TAB: return "TAB";
        case VK_CAPITAL: return "CAPS LOCK";
        case VK_ESCAPE: return "ESC";
        default:
            if (vk >= 0x41 && vk <= 0x5A) {
                static char buffer[2];
                buffer[0] = (char)vk;
                buffer[1] = '\0';
                return buffer;
            }
            if (vk >= 0x30 && vk <= 0x39) {
                static char buffer[2];
                buffer[0] = (char)vk;
                buffer[1] = '\0';
                return buffer;
            }
            return "UNKNOWN";
        }
    }

    int DetectKeyPress() {
        static const int keys[] = {
            VK_F1, VK_F2, VK_F3, VK_F4, VK_F5, VK_F6, VK_F7, VK_F8, VK_F9, VK_F10, VK_F11, VK_F12,
            VK_INSERT, VK_DELETE, VK_HOME, VK_END, VK_PRIOR, VK_NEXT,
            VK_XBUTTON1, VK_XBUTTON2, VK_MBUTTON,
            'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
            'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
            '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
            VK_SHIFT, VK_CONTROL, VK_MENU, VK_SPACE, VK_TAB
        };

        for (int key : keys) {
            if (GetAsyncKeyState(key) & 0x8000) {
                return key;
            }
        }

        return 0;
    }

    bool KeybindButton(const char* label, int* keybind) {
        bool changed = false;

        ImGui::Text("%s", label);
        ImGui::SameLine(250);

        char buttonText[64];
        if (g_CurrentlyBinding == keybind) {
            snprintf(buttonText, sizeof(buttonText), "Press any key...");

            int newKey = DetectKeyPress();
            if (newKey != 0) {
                *keybind = newKey;
                g_CurrentlyBinding = nullptr;
                changed = true;
                ConfigLoader::SaveConfig();
            }

            if (GetAsyncKeyState(VK_ESCAPE) & 0x8000) {
                g_CurrentlyBinding = nullptr;
            }
        }
        else {
            snprintf(buttonText, sizeof(buttonText), "%s", VKToString(*keybind));
        }

        ImVec4 buttonColor = g_CurrentlyBinding == keybind ?
            ImVec4(0.8f, 0.5f, 0.2f, 1.0f) : ImVec4(0.2f, 0.5f, 0.8f, 0.8f);

        ImGui::PushStyleColor(ImGuiCol_Button, buttonColor);
        if (ImGui::Button(buttonText, ImVec2(150, 0))) {
            g_CurrentlyBinding = keybind;
        }
        ImGui::PopStyleColor();

        return changed;
    }

    bool Initialize(HWND hwnd, ID3D11Device* device, ID3D11DeviceContext* context) {
        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        ImGuiIO& io = ImGui::GetIO();

        io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
        io.ConfigFlags &= ~ImGuiConfigFlags_NoMouse;
        io.MouseDrawCursor = false;

        io.Fonts->AddFontDefault();

        ImGui::StyleColorsDark();

        ImGuiStyle& style = ImGui::GetStyle();
        style.WindowRounding = 5.0f;
        style.FrameRounding = 3.0f;
        style.ScrollbarRounding = 3.0f;
        style.GrabRounding = 3.0f;
        style.WindowTitleAlign = ImVec2(0.5f, 0.5f);
        style.WindowPadding = ImVec2(10.0f, 10.0f);
        style.FramePadding = ImVec2(5.0f, 4.0f);
        style.ItemSpacing = ImVec2(8.0f, 6.0f);

        ImVec4* colors = style.Colors;
        colors[ImGuiCol_WindowBg] = ImVec4(0.1f, 0.1f, 0.1f, 0.95f);
        colors[ImGuiCol_TitleBg] = ImVec4(0.2f, 0.2f, 0.2f, 1.0f);
        colors[ImGuiCol_TitleBgActive] = ImVec4(0.3f, 0.3f, 0.3f, 1.0f);
        colors[ImGuiCol_Button] = ImVec4(0.2f, 0.5f, 0.8f, 0.8f);
        colors[ImGuiCol_ButtonHovered] = ImVec4(0.3f, 0.6f, 0.9f, 1.0f);
        colors[ImGuiCol_ButtonActive] = ImVec4(0.1f, 0.4f, 0.7f, 1.0f);

        if (!ImGui_ImplWin32_Init(hwnd)) return false;
        if (!ImGui_ImplDX11_Init(device, context)) return false;

        io.Fonts->Build();

        g_Initialized = true;

        HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
        SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
        std::cout << "[+] ImGui initialized successfully" << std::endl;
        SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

        return true;
    }

    void Shutdown() {
        if (g_Initialized) {
            ImGui_ImplDX11_Shutdown();
            ImGui_ImplWin32_Shutdown();
            ImGui::DestroyContext();
            g_Initialized = false;
        }
    }

    void Render() {
        if (!g_ShowMenu || !g_Initialized) return;

        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

        ImGui::SetNextWindowSize(ImVec2(700, 500), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowPos(ImVec2(100, 100), ImGuiCond_FirstUseEver);

        ImGuiWindowFlags window_flags = ImGuiWindowFlags_NoCollapse;

        ImDrawList* bg_draw = ImGui::GetBackgroundDrawList();
        bg_draw->AddRectFilled(
            ImVec2(0, 0),
            ImVec2(ImGui::GetIO().DisplaySize.x, ImGui::GetIO().DisplaySize.y),
            IM_COL32(0, 0, 0, 150)
        );

        if (ImGui::Begin("Hunter Eye CS2", &g_ShowMenu, window_flags)) {
            RenderMainMenu();
        }
        ImGui::End();

        ImGui::Render();
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
    }

    void RenderMainMenu() {
        ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.5f, 1.0f), "Hunter Eye CS2 - Made by Agente 308 - discord.gg/XbC8g4yfBb");
        ImGui::SameLine();
        ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), " | Press INSERT to close menu");
        ImGui::Separator();

        if (ImGui::BeginTabBar("MainTabs")) {
            if (ImGui::BeginTabItem("ESP")) {
                RenderESPSettings();
                ImGui::EndTabItem();
            }

            if (ImGui::BeginTabItem("Radar")) {
                RenderRadarSettings();
                ImGui::EndTabItem();
            }

            if (ImGui::BeginTabItem("Bomb Timer")) {
                RenderBombTimerSettings();
                ImGui::EndTabItem();
            }

            if (ImGui::BeginTabItem("TriggerBot")) {
                RenderTriggerBotSettings();
                ImGui::EndTabItem();
            }

            if (ImGui::BeginTabItem("Glow")) {
                RenderGlowSettings();
                ImGui::EndTabItem();
            }

            if (ImGui::BeginTabItem("Misc")) {
                RenderMiscSettings();
                ImGui::EndTabItem();
            }

            if (ImGui::BeginTabItem("Keybinds")) {
                RenderKeybindsSettings();
                ImGui::EndTabItem();
            }

            // ✅ NUEVO TAB: CREDITS
            if (ImGui::BeginTabItem("Credits")) {
                RenderCredits();
                ImGui::EndTabItem();
            }

            ImGui::EndTabBar();
        }
    }

    void RenderESPSettings() {
        ImGui::Columns(2, "ESPColumns", true);

        // ═══════════════════════════════════════════════════════════
        // COLUMNA 1: Visual Settings (REORGANIZADO - SIN ESP LINE STYLE)
        // ═══════════════════════════════════════════════════════════
        ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "Visual Settings");
        ImGui::Separator();

        ImGui::Checkbox("Box ESP", &g_config.show_box_esp);
        ImGui::Checkbox("Corner Box", &g_config.use_corner_box);
        ImGui::SliderInt("Box Thickness", &g_config.box_thickness, 1, 5);

        ImGui::Spacing();
        ImGui::Checkbox("Filled Box", &g_config.show_filled_box);
        if (g_config.show_filled_box) {
            ImGui::SliderInt("Fill Alpha", &g_config.filled_box_alpha, 0, 255);
        }

        ImGui::Spacing();
        ImGui::Separator();

        ImGui::Checkbox("Skeleton", &g_config.show_skeleton_esp);
        if (g_config.show_skeleton_esp) {
            ImGui::SliderInt("Skeleton Thickness", &g_config.skeleton_thickness, 1, 5);
        }

        ImGui::Spacing();
        ImGui::Separator();

        ImGui::Checkbox("Head Tracker", &g_config.show_head_tracker);
        ImGui::Checkbox("Health Bar", &g_config.show_health_bar);
        ImGui::Checkbox("Armor Bar", &g_config.show_armor_bar);

        ImGui::Spacing();
        ImGui::Separator();

        ImGui::Checkbox("Snaplines", &g_config.show_snaplines);
        if (g_config.show_snaplines) {
            ImGui::SliderInt("Snapline Thickness", &g_config.snapline_thickness, 1, 5);
        }

        ImGui::NextColumn();

        // ═══════════════════════════════════════════════════════════
        // COLUMNA 2: Info Settings + Colors (REORGANIZADO)
        // ═══════════════════════════════════════════════════════════
        ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 1.0f), "Info Settings");
        ImGui::Separator();

        ImGui::Checkbox("Show Names", &g_config.show_names);
        ImGui::Checkbox("Show Distance", &g_config.show_distance);
        ImGui::Checkbox("Team ESP", &g_config.team_esp);

        ImGui::Spacing();
        ImGui::SliderFloat("Render Distance", &g_config.render_distance, 0.0f, 20000.0f, "%.0f");

        ImGui::Spacing();
        ImGui::Checkbox("Ignore Teammates", &g_config.ignore_teammates);
        ImGui::Checkbox("Ignore Enemies", &g_config.ignore_enemies);

        ImGui::Spacing();
        ImGui::Separator();

        // ═══════════════════════════════════════════════════════════
        // Enemy Colors
        // ═══════════════════════════════════════════════════════════
        ImGui::TextColored(ImVec4(1.0f, 0.3f, 0.3f, 1.0f), "Enemy Colors");
        ImGui::Separator();

        float boxColorEnemy[3] = {
            g_config.box_color_enemy.r / 255.0f,
            g_config.box_color_enemy.g / 255.0f,
            g_config.box_color_enemy.b / 255.0f
        };
        if (ImGui::ColorEdit3("Box Enemy", boxColorEnemy)) {
            g_config.box_color_enemy.r = (int)(boxColorEnemy[0] * 255);
            g_config.box_color_enemy.g = (int)(boxColorEnemy[1] * 255);
            g_config.box_color_enemy.b = (int)(boxColorEnemy[2] * 255);
        }

        float skelColorEnemy[3] = {
            g_config.skeleton_color_enemy.r / 255.0f,
            g_config.skeleton_color_enemy.g / 255.0f,
            g_config.skeleton_color_enemy.b / 255.0f
        };
        if (ImGui::ColorEdit3("Skeleton Enemy", skelColorEnemy)) {
            g_config.skeleton_color_enemy.r = (int)(skelColorEnemy[0] * 255);
            g_config.skeleton_color_enemy.g = (int)(skelColorEnemy[1] * 255);
            g_config.skeleton_color_enemy.b = (int)(skelColorEnemy[2] * 255);
        }

        ImGui::Spacing();
        ImGui::Separator();

        // ═══════════════════════════════════════════════════════════
        // Team Colors
        // ═══════════════════════════════════════════════════════════
        ImGui::TextColored(ImVec4(0.3f, 1.0f, 0.3f, 1.0f), "Team Colors");
        ImGui::Separator();

        float boxColorTeam[3] = {
            g_config.box_color_team.r / 255.0f,
            g_config.box_color_team.g / 255.0f,
            g_config.box_color_team.b / 255.0f
        };
        if (ImGui::ColorEdit3("Box Team", boxColorTeam)) {
            g_config.box_color_team.r = (int)(boxColorTeam[0] * 255);
            g_config.box_color_team.g = (int)(boxColorTeam[1] * 255);
            g_config.box_color_team.b = (int)(boxColorTeam[2] * 255);
        }

        ImGui::Spacing();
        ImGui::Separator();

        // ═══════════════════════════════════════════════════════════
        // Botón de guardar
        // ═══════════════════════════════════════════════════════════
        if (ImGui::Button("Save Configuration", ImVec2(200, 30))) {
            ConfigLoader::SaveConfig();
        }
        ImGui::SameLine();
        ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "Auto-save enabled!");

        ImGui::Columns(1);
    }

    void RenderRadarSettings() {
        ImGui::Checkbox("Enable Radar", &g_config.show_radar);

        if (g_config.show_radar) {
            ImGui::Separator();

            ImGui::SliderFloat("Radar Size", &g_config.radar_size, 50.0f, 500.0f, "%.0f");
            ImGui::SliderFloat("Radar Zoom", &g_config.radar_zoom, 500.0f, 10000.0f, "%.0f");
            ImGui::SliderFloat("Radar X Position", &g_config.radar_x, 0.0f, 1920.0f, "%.0f");
            ImGui::SliderFloat("Radar Y Position", &g_config.radar_y, 0.0f, 1080.0f, "%.0f");

            ImGui::Checkbox("Show Names on Radar", &g_config.radar_show_names);
        }
    }

    void RenderBombTimerSettings() {
        ImGui::Checkbox("Enable Bomb Timer", &g_config.show_bomb_timer);

        if (g_config.show_bomb_timer) {
            ImGui::Separator();

            ImGui::SliderFloat("Timer X Position", &g_config.bomb_timer_x, 0.0f, 1920.0f, "%.0f");
            ImGui::SliderFloat("Timer Y Position", &g_config.bomb_timer_y, 0.0f, 1080.0f, "%.0f");
        }
    }

    void RenderTriggerBotSettings() {
        ImGui::Checkbox("Enable TriggerBot", &g_triggerbot.enabled);

        if (g_triggerbot.enabled) {
            ImGui::Separator();

            ImGui::SliderInt("Delay Min (ms)", &g_triggerbot.delay_min, 5, 100);
            ImGui::SliderInt("Delay Max (ms)", &g_triggerbot.delay_max, 10, 150);

            ImGui::Checkbox("Ignore Teammates", &g_triggerbot.ignore_teammates);
            ImGui::Checkbox("Require Key", &g_triggerbot.require_key);
            ImGui::Checkbox("Burst Mode", &g_triggerbot.burst_mode);

            if (g_triggerbot.burst_mode) {
                ImGui::SliderInt("Burst Count", &g_triggerbot.burst_count, 1, 10);
                ImGui::SliderInt("Burst Delay (ms)", &g_triggerbot.burst_delay, 20, 200);
            }

            ImGui::Spacing();
            ImGui::Text("Hotkey: Configurable in Keybinds tab");
        }
    }

    void RenderGlowSettings() {
        ImGui::Checkbox("Enable Glow", &g_config.glow_enabled);

        if (g_config.glow_enabled) {
            ImGui::Separator();

            ImGui::Checkbox("Glow Enemies", &g_config.glow_enemies);
            ImGui::Checkbox("Glow Teammates", &g_config.glow_teammates);

            ImGui::Spacing();
            ImGui::Text("Glow Settings");
            ImGui::Separator();

            const char* glowTypes[] = { "Disabled", "Full Body", "Pulse", "Outline" };
            ImGui::Combo("Glow Type", &g_config.glow_type, glowTypes, IM_ARRAYSIZE(glowTypes));

            ImGui::SliderInt("Glow Alpha", &g_config.glow_alpha, 0, 255);

            ImGui::Spacing();
            ImGui::Text("Enemy Glow Color");
            ImGui::Separator();

            float enemyColor[3] = {
                g_config.glow_color_enemy.r / 255.0f,
                g_config.glow_color_enemy.g / 255.0f,
                g_config.glow_color_enemy.b / 255.0f
            };
            if (ImGui::ColorEdit3("Enemy Glow", enemyColor)) {
                g_config.glow_color_enemy.r = (int)(enemyColor[0] * 255);
                g_config.glow_color_enemy.g = (int)(enemyColor[1] * 255);
                g_config.glow_color_enemy.b = (int)(enemyColor[2] * 255);
            }

            ImGui::Spacing();
            ImGui::Text("Team Glow Color");
            ImGui::Separator();

            float teamColor[3] = {
                g_config.glow_color_team.r / 255.0f,
                g_config.glow_color_team.g / 255.0f,
                g_config.glow_color_team.b / 255.0f
            };
            if (ImGui::ColorEdit3("Team Glow", teamColor)) {
                g_config.glow_color_team.r = (int)(teamColor[0] * 255);
                g_config.glow_color_team.g = (int)(teamColor[1] * 255);
                g_config.glow_color_team.b = (int)(teamColor[2] * 255);
            }
        }
    }

    void RenderMiscSettings() {
        ImGui::Text("FOV Changer");
        ImGui::Separator();

        ImGui::Checkbox("Enable FOV Changer", &g_config.fov_changer_enabled);
        if (g_config.fov_changer_enabled) {
            ImGui::SliderInt("Desired FOV", &g_config.desired_fov, 60, 140);
            ImGui::Checkbox("Ignore Scope", &g_config.fov_ignore_scope);
        }

        ImGui::Spacing();
        ImGui::Text("Bhop");
        ImGui::Separator();

        ImGui::Checkbox("Enable Bhop", &g_config.bhop_enabled);
        if (g_config.bhop_enabled) {
            ImGui::SliderInt("Bhop Delay (ms)", &g_config.bhop_delay, 5, 50);
        }

        ImGui::Spacing();
        ImGui::Text("Default Keybinds");
        ImGui::Separator();

        ImGui::TextColored(ImVec4(0.7f, 0.7f, 0.7f, 1.0f), "You can customize keybinds in the Keybinds tab");
        ImGui::Text("INSERT: Toggle Menu");
        ImGui::Text("END: Exit Program");
    }

    void RenderKeybindsSettings() {
        ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "Click on any button to change the keybind");
        ImGui::TextColored(ImVec4(0.7f, 0.7f, 0.7f, 1.0f), "Press ESC to cancel binding");
        ImGui::Separator();
        ImGui::Spacing();

        ImGui::Text("Feature Toggles");
        ImGui::Separator();

        KeybindButton("Toggle ESP", &g_keybinds.esp_toggle);
        KeybindButton("Toggle Radar", &g_keybinds.radar_toggle);
        KeybindButton("Toggle Bomb Timer", &g_keybinds.bomb_toggle);
        KeybindButton("Toggle TriggerBot", &g_keybinds.triggerbot_toggle);

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Text("TriggerBot Hotkey");
        ImGui::Separator();

        KeybindButton("TriggerBot Fire Key", &g_triggerbot.hotkey);

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Text("System Keybinds (Hardcoded)");
        ImGui::Separator();

        ImGui::TextColored(ImVec4(0.5f, 0.8f, 1.0f, 1.0f), "INSERT: Toggle Menu");
        ImGui::TextColored(ImVec4(0.5f, 0.8f, 1.0f, 1.0f), "END: Exit Program");
        ImGui::TextColored(ImVec4(0.5f, 0.8f, 1.0f, 1.0f), "F5: Toggle Bhop");

        ImGui::Spacing();
        ImGui::Separator();

        if (ImGui::Button("Reset to Defaults", ImVec2(200, 30))) {
            g_keybinds.esp_toggle = VK_F1;
            g_keybinds.radar_toggle = VK_F2;
            g_keybinds.bomb_toggle = VK_F3;
            g_keybinds.triggerbot_toggle = VK_F4;
            g_triggerbot.hotkey = VK_XBUTTON1;

            ConfigLoader::SaveConfig();
        }
        ImGui::SameLine();
        ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "Keybinds reset!");

        ImGui::Spacing();

        if (ImGui::Button("Save Config Now", ImVec2(200, 30))) {
            ConfigLoader::SaveConfig();
        }
        ImGui::SameLine();
        ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "Config saved!");
    }

    // ═══════════════════════════════════════════════════════════
    // ✅ NUEVA FUNCIÓN: CREDITS
    // ═══════════════════════════════════════════════════════════
    void RenderCredits() {
        ImGui::Spacing();
        ImGui::Spacing();

        // Logo/Title
        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.0f, 1.0f, 0.5f, 1.0f));
        ImGui::SetWindowFontScale(1.5f);
        ImGui::Text("Hunter Eye CS2");
        ImGui::SetWindowFontScale(1.0f);
        ImGui::PopStyleColor();

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        // Developer
        ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "Developer:");
        ImGui::Indent(20.0f);
        ImGui::TextColored(ImVec4(1.0f, 1.0f, 1.0f, 1.0f), "Agente 308");
        ImGui::Unindent(20.0f);

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        // Features
        ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "Features:");
        ImGui::Indent(20.0f);
        ImGui::BulletText("ESP with customizable colors and styles");
        ImGui::BulletText("Skeleton ESP");
        ImGui::BulletText("Health & Armor Bars");
        ImGui::BulletText("2D Radar");
        ImGui::BulletText("Bomb Timer");
        ImGui::BulletText("TriggerBot with burst mode");
        ImGui::BulletText("Glow ESP");
        ImGui::BulletText("FOV Changer");
        ImGui::BulletText("Bunny Hop (Bhop)");
        ImGui::BulletText("Customizable Keybinds");
        ImGui::Unindent(20.0f);

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        // Discord
        ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "Community:");
        ImGui::Indent(20.0f);
        ImGui::TextColored(ImVec4(0.5f, 0.8f, 1.0f, 1.0f), "Discord: discord.gg/XbC8g4yfBb");
        ImGui::Unindent(20.0f);

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        // Version
        ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), "Version:");
        ImGui::Indent(20.0f);
        ImGui::Text("v1.0.0 - 2025");
        ImGui::Unindent(20.0f);

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        // Warning
        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 0.3f, 0.3f, 1.0f));
        ImGui::TextWrapped("WARNING: Use at your own risk. This tool is for educational purposes only.");
        ImGui::PopStyleColor();

        ImGui::Spacing();
        ImGui::Spacing();

        // Footer
        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.7f, 0.7f, 0.7f, 1.0f));
        ImGui::Text("Thank you for using Hunter Eye CS2!");
        ImGui::PopStyleColor();
    }
}