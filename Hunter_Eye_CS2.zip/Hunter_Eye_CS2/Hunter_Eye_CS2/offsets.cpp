﻿#include "offsets.h"
#include <wininet.h>
#pragma comment(lib, "wininet.lib")
#include <iostream>
#include <fstream>
#include <string>

namespace offsets {
    uintptr_t dwLocalPlayerController = 0;
    uintptr_t dwLocalPlayerPawn = 0;
    uintptr_t dwEntityList = 0;
    uintptr_t dwViewMatrix = 0;
    uintptr_t dwBuildNumber = 0;
    uintptr_t dwPlantedC4 = 0;
    uintptr_t dwForceJump = 0;

    uintptr_t m_hPlayerPawn = 0;
    uintptr_t m_iHealth = 0;
    uintptr_t m_ArmorValue = 0;
    uintptr_t m_iTeamNum = 0;
    uintptr_t m_vOldOrigin = 0;
    uintptr_t m_pGameSceneNode = 0;
    uintptr_t m_vecAbsOrigin = 0;
    uintptr_t m_iszPlayerName = 0;
    uintptr_t m_entitySpottedState = 0;
    uintptr_t m_hController = 0;
    uintptr_t m_angEyeAngles = 0;

    uintptr_t m_flFlashOverlayAlpha = 0;
    uintptr_t m_bIsScoped = 0;
    uintptr_t m_vecAbsVelocity = 0;
    uintptr_t m_iIDEntIndex = 0;

    uintptr_t m_pCameraServices = 0;
    uintptr_t m_iFOV = 0;
    uintptr_t m_iFOVStart = 0;

    uintptr_t m_flC4Blow = 0;
    uintptr_t m_nBombSite = 0;
    uintptr_t m_flTimerLength = 0;
    uintptr_t m_bBombPlanted = 0;
    uintptr_t m_flNextBeep = 0;

    uintptr_t m_Glow = 0; 

    uintptr_t m_glowColorOverride = 0x40;  
    uintptr_t m_iGlowType = 0x30;           
    uintptr_t m_bGlowing = 0x51;          
    uintptr_t m_lifeState = 0;

    uintptr_t findValueInJson(const std::string& json, const std::string& key) {
        std::string searchKey = "\"" + key + "\"";
        size_t pos = json.find(searchKey);

        if (pos == std::string::npos) {
            return 0;
        }

        size_t colonPos = json.find(":", pos);
        if (colonPos == std::string::npos) {
            return 0;
        }

        size_t searchStart = colonPos + 1;
        while (searchStart < json.length() &&
            (json[searchStart] == ' ' || json[searchStart] == '\t' ||
                json[searchStart] == '\n' || json[searchStart] == '\r')) {
            searchStart++;
        }

        if (searchStart < json.length() && json[searchStart] == '{') {
            size_t valuePos = json.find("\"value\"", searchStart);
            if (valuePos != std::string::npos && valuePos < searchStart + 500) {
                colonPos = json.find(":", valuePos);
                if (colonPos != std::string::npos) {
                    searchStart = colonPos + 1;
                }
            }
        }

        while (searchStart < json.length() &&
            (json[searchStart] == ' ' || json[searchStart] == '\t' ||
                json[searchStart] == '\n' || json[searchStart] == '\r')) {
            searchStart++;
        }

        std::string numStr;
        bool isHex = false;

        if (searchStart + 1 < json.length() &&
            json[searchStart] == '0' && (json[searchStart + 1] == 'x' || json[searchStart + 1] == 'X')) {
            isHex = true;
            searchStart += 2;
        }

        while (searchStart < json.length()) {
            char c = json[searchStart];
            if (isHex) {
                if (isxdigit(c)) {
                    numStr += c;
                }
                else {
                    break;
                }
            }
            else {
                if (isdigit(c) || (numStr.empty() && c == '-')) {
                    numStr += c;
                }
                else {
                    break;
                }
            }
            searchStart++;
        }

        if (numStr.empty()) {
            return 0;
        }

        try {
            if (isHex) {
                return std::stoull(numStr, nullptr, 16);
            }
            else {
                return std::stoull(numStr);
            }
        }
        catch (...) {
            return 0;
        }
    }

    bool LoadFromURL() {
        std::cout << "[*] Downloading offsets from GitHub" << std::endl;

        const char* url_offsets = "https://raw.githubusercontent.com/a2x/cs2-dumper/main/output/offsets.json";
        const char* url_client = "https://raw.githubusercontent.com/a2x/cs2-dumper/main/output/client_dll.json";
        const char* url_buttons = "https://raw.githubusercontent.com/a2x/cs2-dumper/main/output/buttons.json";

        HINTERNET hInternet = InternetOpenA("CS2-ESP", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
        if (!hInternet) {
            std::cout << "[-] Failed to initialize internet connection" << std::endl;
            return false;
        }

        std::cout << "[*] Downloading offsets.json" << std::endl;
        HINTERNET hConnect = InternetOpenUrlA(hInternet, url_offsets, NULL, 0,
            INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE, 0);
        if (!hConnect) {
            std::cout << "[-] Failed to download offsets.json" << std::endl;
            InternetCloseHandle(hInternet);
            return false;
        }

        std::string jsonOffsets;
        char buffer[4096];
        DWORD bytesRead;

        while (InternetReadFile(hConnect, buffer, sizeof(buffer), &bytesRead) && bytesRead > 0) {
            jsonOffsets.append(buffer, bytesRead);
        }
        InternetCloseHandle(hConnect);

        std::cout << "[+] Downloaded offsets.json" << std::endl;

        std::cout << "[*] Downloading client_dll.json" << std::endl;
        hConnect = InternetOpenUrlA(hInternet, url_client, NULL, 0,
            INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE, 0);
        if (!hConnect) {
            std::cout << "[-] Failed to download client_dll.json" << std::endl;
            InternetCloseHandle(hInternet);
            return false;
        }

        std::string jsonClient;
        while (InternetReadFile(hConnect, buffer, sizeof(buffer), &bytesRead) && bytesRead > 0) {
            jsonClient.append(buffer, bytesRead);
        }
        InternetCloseHandle(hConnect);

        std::cout << "[+] Downloaded client_dll.json" << std::endl;

        std::cout << "[*] Downloading buttons.json" << std::endl;
        hConnect = InternetOpenUrlA(hInternet, url_buttons, NULL, 0,
            INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE, 0);
        if (!hConnect) {
            std::cout << "[-] Failed to download buttons.json" << std::endl;
            InternetCloseHandle(hInternet);
            return false;
        }

        std::string jsonButtons;
        while (InternetReadFile(hConnect, buffer, sizeof(buffer), &bytesRead) && bytesRead > 0) {
            jsonButtons.append(buffer, bytesRead);
        }
        InternetCloseHandle(hConnect);

        std::cout << "[+] Downloaded buttons.json" << std::endl;

        InternetCloseHandle(hInternet);

        if (jsonOffsets.empty() || jsonClient.empty() || jsonButtons.empty()) {
            std::cout << "[-] One or more JSON files are empty" << std::endl;
            return false;
        }

        std::cout << "[*] Parsing offsets from offsets.json" << std::endl;

        size_t clientDllStart = jsonOffsets.find("\"client.dll\"");
        if (clientDllStart != std::string::npos) {
            std::string clientSection = jsonOffsets.substr(clientDllStart);

            dwLocalPlayerController = findValueInJson(clientSection, "dwLocalPlayerController");
            dwLocalPlayerPawn = findValueInJson(clientSection, "dwLocalPlayerPawn");
            dwEntityList = findValueInJson(clientSection, "dwEntityList");
            dwViewMatrix = findValueInJson(clientSection, "dwViewMatrix");
            dwPlantedC4 = findValueInJson(clientSection, "dwPlantedC4");
            m_flC4Blow = findValueInJson(jsonClient, "m_flC4Blow");
            m_nBombSite = findValueInJson(jsonClient, "m_nBombSite");
            m_flTimerLength = findValueInJson(jsonClient, "m_flTimerLength");
            m_bBombPlanted = findValueInJson(jsonClient, "m_bBombPlanted");
            m_flNextBeep = findValueInJson(jsonClient, "m_flNextBeep");
        }
        else {
            std::cout << "[-] Could not find 'client.dll' section in offsets.json" << std::endl;
        }

        std::cout << "[*] Parsing offsets from buttons.json" << std::endl;

        size_t clientDllButtonsStart = jsonButtons.find("\"client.dll\"");
        if (clientDllButtonsStart != std::string::npos) {
            std::string buttonsClientSection = jsonButtons.substr(clientDllButtonsStart);
            dwForceJump = findValueInJson(buttonsClientSection, "jump");
        }
        else {
            std::cout << "[-] Could not find 'client.dll' section in buttons.json" << std::endl;
        }

        std::cout << "[*] Parsing offsets from client_dll.json" << std::endl;

        m_hPlayerPawn = findValueInJson(jsonClient, "m_hPlayerPawn");
        m_iHealth = findValueInJson(jsonClient, "m_iHealth");
        m_ArmorValue = findValueInJson(jsonClient, "m_ArmorValue");
        m_iTeamNum = findValueInJson(jsonClient, "m_iTeamNum");
        m_vOldOrigin = findValueInJson(jsonClient, "m_vOldOrigin");
        m_pGameSceneNode = findValueInJson(jsonClient, "m_pGameSceneNode");
        m_vecAbsOrigin = findValueInJson(jsonClient, "m_vecAbsOrigin");
        m_iszPlayerName = findValueInJson(jsonClient, "m_iszPlayerName");
        m_entitySpottedState = findValueInJson(jsonClient, "m_entitySpottedState");
        m_hController = findValueInJson(jsonClient, "m_hController");
        m_angEyeAngles = findValueInJson(jsonClient, "m_angEyeAngles");
        m_pCameraServices = findValueInJson(jsonClient, "m_pCameraServices");
        m_iFOV = findValueInJson(jsonClient, "m_iFOV");
        m_iFOVStart = findValueInJson(jsonClient, "m_iFOVStart");

        m_flFlashOverlayAlpha = findValueInJson(jsonClient, "m_flFlashOverlayAlpha");
        m_bIsScoped = findValueInJson(jsonClient, "m_bIsScoped");
        m_vecAbsVelocity = findValueInJson(jsonClient, "m_vecAbsVelocity");
        m_iIDEntIndex = findValueInJson(jsonClient, "m_iIDEntIndex");

        std::cout << "[*] Parsing glow offsets from client_dll.json" << std::endl;

        m_Glow = findValueInJson(jsonClient, "m_Glow");

        m_lifeState = findValueInJson(jsonClient, "m_lifestate");
        if (m_lifeState == 0) {
            m_lifeState = findValueInJson(jsonClient, "m_lifeState");
        }
        if (m_lifeState == 0) {
            m_lifeState = findValueInJson(jsonClient, "m_LifeState");
        }

        bool success = (dwLocalPlayerController != 0 && dwEntityList != 0 && dwViewMatrix != 0 &&
            m_hPlayerPawn != 0 && m_iHealth != 0 && m_iTeamNum != 0 && dwForceJump != 0);

        HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

        if (success) {
            SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
            std::cout << "[+] All critical offsets loaded successfully!" << std::endl;

            SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | FOREGROUND_INTENSITY);
            std::cout << "\n[+] Glow offsets:" << std::endl;
            std::cout << "    m_Glow (CGlowProperty):  0x" << std::hex << m_Glow << std::dec;
            if (m_Glow == 0) {
                SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_INTENSITY);
                std::cout << " [NOT FOUND - Glow will not work!]" << std::endl;
            }
            else {
                std::cout << " [OK]" << std::endl;
            }

            SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | FOREGROUND_INTENSITY);
            std::cout << "    CGlowProperty internals (hardcoded):" << std::endl;
            std::cout << "      m_glowColorOverride: 0x" << std::hex << m_glowColorOverride << std::dec << std::endl;
            std::cout << "      m_iGlowType:         0x" << std::hex << m_iGlowType << std::dec << std::endl;
            std::cout << "      m_bGlowing:          0x" << std::hex << m_bGlowing << std::dec << std::endl;
            std::cout << "    m_lifeState:           0x" << std::hex << m_lifeState << std::dec;
            if (m_lifeState == 0) {
                SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_INTENSITY);
                std::cout << " [NOT FOUND - Using default 0x354]" << std::endl;
                m_lifeState = 0x354;
            }
            else {
                std::cout << " [OK]" << std::endl;
            }

            SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
        }
        else {
            SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_INTENSITY);
            std::cout << "[-] Failed to load some critical offsets" << std::endl;
            SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
        }

        return success;
    }
}