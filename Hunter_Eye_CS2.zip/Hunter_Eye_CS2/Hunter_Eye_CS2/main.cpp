﻿#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <iostream>
#include <thread>
#include <memory>
#include <chrono>
#include <fstream>
#include <ctime>

#include "common.h"
#include "process.h"
#include "offsets.h"
#include "config.h"
#include "game.h"
#include "render.h"
#include "render_dx11.h"
#include "imgui_menu.h"

#include "features/bhop.h"
#include "features/fov_changer.h"
#include "features/triggerbot.h"
#include "features/bomb_timer.h"
#include "features/radar.h"
#include "features/esp.h"
#include "features/glow.h"

#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include <d3d11.h>

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

std::unique_ptr<AutoBhop> g_bhop_instance = nullptr;
std::unique_ptr<FOVChanger> g_fov_changer_instance = nullptr;
std::unique_ptr<TriggerBot> g_triggerbot_instance = nullptr;
std::unique_ptr<PlayerGlow> g_glow_instance = nullptr;

HWND g_hwnd_gdi = nullptr;
HWND g_hwnd_dx11 = nullptr;

FILE* g_logFile = nullptr;

void DebugLog(const char* message) {
    char timeStr[100];
    time_t now = time(NULL);
    struct tm timeInfo;
    localtime_s(&timeInfo, &now);
    strftime(timeStr, sizeof(timeStr), "%H:%M:%S", &timeInfo);

    printf("[%s] %s\n", timeStr, message);

    if (g_logFile) {
        fprintf(g_logFile, "[%s] %s\n", timeStr, message);
        fflush(g_logFile);
    }
}

namespace MenuState {
    bool isOpen = false;
    bool togglePressed = false;
}

void printAsciiArt() {
    SetConsoleOutputCP(CP_UTF8);
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    DWORD written;

    const wchar_t* lines[] = {
        L"\n",
        L"   ⠀⠀⣿⠲⠤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n",
        L"   ⠀⣸⡏⠀⠀⠀⠉⠳⢄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n",
        L"   ⠀⣿⠀⠀⠀⠀⠀⠀⠀⠉⠲⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n",
        L"   ⢰⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠲⣄⠀⠀⠀⡰⠋⢙⣿⣦⡀⠀⠀⠀⠀⠀\n",
        L"   ⠸⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣙⣦⣮⣤⡀⣸⣿⣿⣿⣆⠀⠀⠀⠀\n",
        L"   ⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⣿⣿⣿⠀⣿⢟⣫⠟⠋⠀⠀⠀⠀\n",
        L"   ⠀⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣷⣷⣿⡁⠀⠀⠀⠀⠀⠀\n",
        L"   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⢹⣿⣿⣧⣿⣿⣆⡹⣖⡀⠀⠀⠀⠀\n",
        L"   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢾⣿⣤⣿⣿⣿⡟⠹⣿⣿⣿⣿⣷⡀⠀⠀\n",
        L"   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣧⣴⣿⣿⣿⣿⠏⢧⠀⠀\n",
        L"   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠀⠈⢳⡀\n",
        L"   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⡏⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⢳\n",
        L"   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⢀⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀\n",
        L"   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡇⠸⣿⣿⣿⣿⣿⣿⣿⣿⠏⠀⠀⠀⠀⠀⠀\n",
        L"   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡇⠀⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀\n",
        L"   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⡇⢠⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀\n",
        L"   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠃⢸⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀\n",
        L"   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣼⢸⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀\n",
        L"   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣾⣿⢸⣿⣿⣿⣿⣿⣿⣿⣿⡄⠀⠀⠀⠀⠀⠀\n",
        L"   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⣿⣿⣾⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀\n",
        L"   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⠀⠀⠀⠀⠀⠀\n",
        L"   ⠀⠀⠀⠀⠀⠀⠀⢀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀\n",
        L"   ⠀⠀⠀⠀⠀⠀⠀⠛⠻⠿⣿⣿⣿⡿⠿⠿⠿⠿⠿⢿⣿⣿⠏⠀⠀⠀⠀⠀⠀\n",
        L"\n"
    };

    for (int i = 0; i < sizeof(lines) / sizeof(lines[0]); i++) {
        WriteConsoleW(hConsole, lines[i], (DWORD)wcslen(lines[i]), &written, NULL);
    }
}

void ConfigWatcherThread() {
    HANDLE hDir = CreateFileA(".", FILE_LIST_DIRECTORY,
        FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
        NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL);

    if (hDir == INVALID_HANDLE_VALUE) return;

    char buffer[1024];
    DWORD bytesReturned;
    FILE_NOTIFY_INFORMATION* pNotify;

    while (g_running) {
        if (ReadDirectoryChangesW(hDir, buffer, sizeof(buffer), FALSE,
            FILE_NOTIFY_CHANGE_LAST_WRITE, &bytesReturned, NULL, NULL)) {
            pNotify = (FILE_NOTIFY_INFORMATION*)buffer;

            do {
                WCHAR filename[MAX_PATH];
                wcsncpy_s(filename, pNotify->FileName, pNotify->FileNameLength / sizeof(WCHAR));
                filename[pNotify->FileNameLength / sizeof(WCHAR)] = L'\0';

                if (wcsstr(filename, L"hunter_eye_config.json") != NULL) {
                    std::this_thread::sleep_for(std::chrono::milliseconds(50));
                    ConfigLoader::LoadConfig();
                }

                if (pNotify->NextEntryOffset == 0) break;
                pNotify = (FILE_NOTIFY_INFORMATION*)((BYTE*)pNotify + pNotify->NextEntryOffset);
            } while (true);
        }
    }

    CloseHandle(hDir);
}

void SetCursorVisibility(bool visible) {
    if (visible) {
        int count = 0;
        while (ShowCursor(TRUE) < 0 && count++ < 100) {}
    }
    else {
        int count = 0;
        while (ShowCursor(FALSE) >= 0 && count++ < 100) {}
    }
}

void ToggleMenu() {
    DebugLog(">>> ToggleMenu START");

    MenuState::isOpen = !MenuState::isOpen;
    ImGuiMenu::g_ShowMenu = MenuState::isOpen;

    char msg[256];
    sprintf_s(msg, "Menu state changing to: %s", MenuState::isOpen ? "OPEN" : "CLOSED");
    DebugLog(msg);

    if (MenuState::isOpen) {
        DebugLog("  -> ShowWindow(SW_SHOW)");
        ShowWindow(g_hwnd_dx11, SW_SHOW);

        DebugLog("  -> UpdateWindow");
        UpdateWindow(g_hwnd_dx11);

        DebugLog("  -> SetForegroundWindow");
        SetForegroundWindow(g_hwnd_dx11);

        DebugLog("  -> SetFocus");
        SetFocus(g_hwnd_dx11);

        DebugLog("  -> SetCursorVisibility(true)");
        SetCursorVisibility(true);

        DebugLog("  -> Menu opened successfully");
    }
    else {
        DebugLog("  -> ShowWindow(SW_HIDE)");
        ShowWindow(g_hwnd_dx11, SW_HIDE);

        DebugLog("  -> SetCursorVisibility(false)");
        SetCursorVisibility(false);

        DebugLog("  -> Menu closed successfully");
    }

    DebugLog("<<< ToggleMenu END");
}

void HandleKeybinds() {
    bool insertPressed = (GetAsyncKeyState(VK_INSERT) & 0x8000) != 0;

    if (insertPressed && !MenuState::togglePressed) {
        DebugLog("!!! INSERT KEY DETECTED !!!");
        ToggleMenu();
        MenuState::togglePressed = true;
    }
    else if (!insertPressed) {
        MenuState::togglePressed = false;
    }

    static bool esp_pressed = false;
    if (GetAsyncKeyState(g_keybinds.esp_toggle) & 0x8000) {
        if (!esp_pressed) {
            g_config.show_box_esp = !g_config.show_box_esp;
            esp_pressed = true;
        }
    }
    else esp_pressed = false;

    static bool radar_pressed = false;
    if (GetAsyncKeyState(g_keybinds.radar_toggle) & 0x8000) {
        if (!radar_pressed) {
            g_config.show_radar = !g_config.show_radar;
            radar_pressed = true;
        }
    }
    else radar_pressed = false;

    static bool bomb_pressed = false;
    if (GetAsyncKeyState(g_keybinds.bomb_toggle) & 0x8000) {
        if (!bomb_pressed) {
            g_config.show_bomb_timer = !g_config.show_bomb_timer;
            bomb_pressed = true;
        }
    }
    else bomb_pressed = false;

    static bool triggerbot_pressed = false;
    if (GetAsyncKeyState(g_keybinds.triggerbot_toggle) & 0x8000) {
        if (!triggerbot_pressed) {
            g_triggerbot.enabled = !g_triggerbot.enabled;
            triggerbot_pressed = true;
        }
    }
    else triggerbot_pressed = false;

    static bool bhop_pressed = false;
    if (GetAsyncKeyState(VK_F5) & 0x8000) {
        if (!bhop_pressed) {
            g_config.bhop_enabled = !g_config.bhop_enabled;
            bhop_pressed = true;
        }
    }
    else bhop_pressed = false;
}

void ReadThread() {
    bool firstInGame = false;

    auto GetOptimalDelay = []() -> int {
        if (g_config.bhop_enabled) return 3;
        if (g_triggerbot.enabled) return 5;
        if (g_config.glow_enabled) return 5;
        return 8;
        };

    while (g_running) {
        BombTimer::UpdateBombStatus();

        if (!g_game.loop()) {
            g_running = false;
            break;
        }

        if (!g_game.inGame) {
            if (firstInGame) firstInGame = false;
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
            continue;
        }

        if (!firstInGame) firstInGame = true;

        if (g_config.glow_enabled) {
            if (!g_glow_instance) {
                g_glow_instance = std::make_unique<PlayerGlow>(
                    g_game.process, g_game.base_client);
            }
            g_glow_instance->Run();
        }
        else {
            if (g_glow_instance) g_glow_instance.reset();
        }

        if (g_triggerbot.enabled) {
            if (!g_triggerbot_instance) {
                g_triggerbot_instance = std::make_unique<TriggerBot>(
                    g_game.process, g_game.base_client);
            }

            uintptr_t localPlayer = g_game.process->read<uintptr_t>(
                g_game.base_client.base + offsets::dwLocalPlayerController);

            if (localPlayer) {
                uint32_t localPlayerPawn = g_game.process->read<uint32_t>(
                    localPlayer + offsets::m_hPlayerPawn);

                if (localPlayerPawn) {
                    uintptr_t entityList = g_game.process->read<uintptr_t>(
                        g_game.base_client.base + offsets::dwEntityList);
                    uintptr_t listEntry = g_game.process->read<uintptr_t>(
                        entityList + 0x8 * ((localPlayerPawn & 0x7FFF) >> 9) + 16);
                    uintptr_t pawn = g_game.process->read<uintptr_t>(
                        listEntry + 112 * (localPlayerPawn & 0x1FF));

                    if (pawn) g_triggerbot_instance->Run(g_game.localTeam, pawn);
                }
            }
        }

        if (g_config.fov_changer_enabled) {
            if (!g_fov_changer_instance) {
                g_fov_changer_instance = std::make_unique<FOVChanger>(
                    g_game.process, g_game.base_client);
            }

            uintptr_t localPlayer = g_game.process->read<uintptr_t>(
                g_game.base_client.base + offsets::dwLocalPlayerController);

            if (localPlayer) {
                uint32_t localPlayerPawn = g_game.process->read<uint32_t>(
                    localPlayer + offsets::m_hPlayerPawn);

                if (localPlayerPawn) {
                    uintptr_t entityList = g_game.process->read<uintptr_t>(
                        g_game.base_client.base + offsets::dwEntityList);
                    uintptr_t listEntry = g_game.process->read<uintptr_t>(
                        entityList + 0x8 * ((localPlayerPawn & 0x7FFF) >> 9) + 16);
                    uintptr_t pawn = g_game.process->read<uintptr_t>(
                        listEntry + 112 * (localPlayerPawn & 0x1FF));

                    if (pawn) g_fov_changer_instance->Run(g_game.localTeam, pawn);
                }
            }
        }

        if (g_config.bhop_enabled) {
            if (!g_bhop_instance) {
                g_bhop_instance = std::make_unique<AutoBhop>(
                    g_game.process, g_game.base_client, offsets::dwForceJump);
            }
            g_bhop_instance->Run(g_config.bhop_delay, true, g_game.process->pid_);
        }
        else {
            if (g_bhop_instance) g_bhop_instance.reset();
        }

        int optimalDelay = GetOptimalDelay();
        std::this_thread::sleep_for(std::chrono::milliseconds(optimalDelay));
    }
}

LRESULT CALLBACK WndProcGDI(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);

        if (render::hdcBuffer && g_game.inGame) {
            PatBlt(render::hdcBuffer, 0, 0,
                g_game.game_bounds.right,
                g_game.game_bounds.bottom,
                BLACKNESS);

            ESP::Render();
            radar::render();
            BombTimer::Render();

            BitBlt(hdc, 0, 0, g_game.game_bounds.right, g_game.game_bounds.bottom,
                render::hdcBuffer, 0, 0, SRCCOPY);
        }

        EndPaint(hWnd, &ps);
        return 0;
    }
    }
    return DefWindowProc(hWnd, msg, wParam, lParam);
}

LRESULT CALLBACK WndProcDX11(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (ImGuiMenu::g_Initialized) {
        if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
            return true;
    }

    switch (msg) {
    case WM_CLOSE:
        DebugLog("WM_CLOSE on DX11 - hiding");
        ShowWindow(hWnd, SW_HIDE);
        MenuState::isOpen = false;
        ImGuiMenu::g_ShowMenu = false;
        SetCursorVisibility(false);
        return 0;

    case WM_DESTROY:
        DebugLog("WM_DESTROY on DX11 - ignoring");
        return 0;

    case WM_SYSCOMMAND:
        if ((wParam & 0xFFF0) == SC_CLOSE) {
            DebugLog("SC_CLOSE - hiding");
            ShowWindow(hWnd, SW_HIDE);
            MenuState::isOpen = false;
            ImGuiMenu::g_ShowMenu = false;
            SetCursorVisibility(false);
            return 0;
        }
        break;
    }

    return DefWindowProc(hWnd, msg, wParam, lParam);
}

int main() {
    fopen_s(&g_logFile, "debug_log.txt", "w");
    if (g_logFile) {
        DebugLog("=== HUNTER EYE DEBUG LOG ===");
    }

    SetConsoleTitleA("Hunter Eye - discord.gg/XbC8g4yfBb");
    printAsciiArt();

    std::cout << "==================================" << std::endl;
    std::cout << "        HUNTER EYE                " << std::endl;
    std::cout << "    (Made by Agente 308)          " << std::endl;
    std::cout << "==================================" << std::endl;

    DebugLog("Loading offsets...");
    if (!offsets::LoadFromURL()) {
        DebugLog("Failed to load offsets");
        std::cin.get();
        return 1;
    }
    DebugLog("Offsets loaded");

    DebugLog("Initializing game...");
    g_game.init();
    DebugLog("Game initialized");

    DebugLog("Loading config...");
    ConfigLoader::LoadConfig();
    DebugLog("Config loaded");

    while (GetForegroundWindow() != g_game.process->hwnd_) {
        std::this_thread::sleep_for(std::chrono::seconds(1));
        g_game.process->UpdateHWND();
    }

    GetClientRect(g_game.process->hwnd_, &g_game.game_bounds);

    DebugLog("Creating GDI window...");
    WNDCLASSEXA wcGDI = {};
    wcGDI.cbSize = sizeof(WNDCLASSEXA);
    wcGDI.lpfnWndProc = WndProcGDI;
    wcGDI.style = CS_HREDRAW | CS_VREDRAW;
    wcGDI.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wcGDI.hInstance = GetModuleHandle(NULL);
    wcGDI.lpszClassName = "HunterEye_GDI";
    RegisterClassExA(&wcGDI);

    g_hwnd_gdi = CreateWindowExA(
        WS_EX_TRANSPARENT | WS_EX_TOPMOST | WS_EX_LAYERED | WS_EX_TOOLWINDOW,
        "HunterEye_GDI", "Features",
        WS_POPUP,
        g_game.game_bounds.left, g_game.game_bounds.top,
        g_game.game_bounds.right, g_game.game_bounds.bottom,
        NULL, NULL, GetModuleHandle(NULL), NULL
    );

    if (!g_hwnd_gdi) {
        DebugLog("Failed to create GDI window");
        std::cerr << "[ERROR] Failed to create GDI window" << std::endl;
        std::cin.get();
        return 1;
    }
    DebugLog("GDI window created");

    SetLayeredWindowAttributes(g_hwnd_gdi, RGB(0, 0, 0), 255, LWA_COLORKEY);
    ShowWindow(g_hwnd_gdi, SW_SHOW);
    UpdateWindow(g_hwnd_gdi);

    DebugLog("Initializing GDI render...");
    render::Init(g_hwnd_gdi, g_game.game_bounds.right, g_game.game_bounds.bottom);
    DebugLog("GDI render initialized");

    DebugLog("Creating DX11 window...");
    WNDCLASSEXA wcDX11 = {};
    wcDX11.cbSize = sizeof(WNDCLASSEXA);
    wcDX11.lpfnWndProc = WndProcDX11;
    wcDX11.style = CS_HREDRAW | CS_VREDRAW;
    wcDX11.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wcDX11.hInstance = GetModuleHandle(NULL);
    wcDX11.lpszClassName = "HunterEye_DX11";
    RegisterClassExA(&wcDX11);

    g_hwnd_dx11 = CreateWindowExA(
        WS_EX_TOPMOST | WS_EX_LAYERED | WS_EX_TOOLWINDOW,
        "HunterEye_DX11", "Menu",
        WS_POPUP,
        g_game.game_bounds.left, g_game.game_bounds.top,
        g_game.game_bounds.right, g_game.game_bounds.bottom,
        NULL, NULL, GetModuleHandle(NULL), NULL
    );

    if (!g_hwnd_dx11) {
        DebugLog("Failed to create DX11 window");
        std::cerr << "[ERROR] Failed to create DX11 window" << std::endl;
        std::cin.get();
        return 1;
    }
    DebugLog("DX11 window created");

    SetLayeredWindowAttributes(g_hwnd_dx11, RGB(0, 0, 0), 255, LWA_COLORKEY);
    ShowWindow(g_hwnd_dx11, SW_HIDE);
    UpdateWindow(g_hwnd_dx11);

    DebugLog("Initializing DirectX 11...");
    if (!RenderDX11::Initialize(g_hwnd_dx11, g_game.game_bounds.right, g_game.game_bounds.bottom)) {
        DebugLog("Failed to initialize DX11");
        std::cerr << "[ERROR] Failed to initialize DX11" << std::endl;
        std::cin.get();
        return 1;
    }
    DebugLog("DX11 initialized");

    DebugLog("Initializing ImGui...");
    if (!ImGuiMenu::Initialize(g_hwnd_dx11, RenderDX11::g_pd3dDevice, RenderDX11::g_pd3dDeviceContext)) {
        DebugLog("Failed to initialize ImGui");
        std::cerr << "[ERROR] Failed to initialize ImGui" << std::endl;
        std::cin.get();
        return 1;
    }
    DebugLog("ImGui initialized");

    std::thread configWatcher(ConfigWatcherThread);
    std::thread reader(ReadThread);

    SetCursorVisibility(false);

    MSG msg;
    auto lastFrameTime = std::chrono::steady_clock::now();
    const auto targetFrameTime = std::chrono::milliseconds(16);

    std::cout << "\n[+] Hunter Eye loaded successfully!" << std::endl;
    std::cout << "[*] Press INSERT to toggle menu" << std::endl;
    std::cout << "[*] Press END to exit" << std::endl;
    std::cout << "[*] Debug log: debug_log.txt" << std::endl;

    DebugLog("Entering main loop...");

    while (g_running) {
        auto currentTime = std::chrono::steady_clock::now();
        auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
            currentTime - lastFrameTime);

        if (elapsed < targetFrameTime) {
            std::this_thread::sleep_for(targetFrameTime - elapsed);
        }
        lastFrameTime = std::chrono::steady_clock::now();

        HandleKeybinds();

        if (GetAsyncKeyState(VK_END) & 0x8000) {
            DebugLog("END key pressed - exiting");
            g_running = false;
            break;
        }

        while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }

        if (!g_running) break;

        if (g_game.inGame) {
            InvalidateRect(g_hwnd_gdi, NULL, FALSE);
        }

        if (MenuState::isOpen && IsWindowVisible(g_hwnd_dx11)) {
            RenderDX11::BeginFrame();
            ImGuiMenu::Render();
            RenderDX11::EndFrame();
        }
    }

    DebugLog("Shutting down...");

    if (reader.joinable()) reader.join();
    if (configWatcher.joinable()) configWatcher.join();

    ImGuiMenu::Shutdown();
    RenderDX11::Cleanup();
    render::Cleanup();

    DestroyWindow(g_hwnd_dx11);
    DestroyWindow(g_hwnd_gdi);

    DebugLog("Cleanup complete");
    std::cout << "[+] Cleanup complete!" << std::endl;

    if (g_logFile) {
        fclose(g_logFile);
    }

    return 0;
}