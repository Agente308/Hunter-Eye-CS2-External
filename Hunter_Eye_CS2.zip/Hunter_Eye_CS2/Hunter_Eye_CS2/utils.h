#pragma once
#include "common.h"

void printAsciiArt();
void HandleKeybinds();
void ConfigWatcherThread();