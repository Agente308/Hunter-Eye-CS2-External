﻿#pragma once
#include "common.h"

enum ESPLineStyle {
    ESP_STYLE_NORMAL = 0,     
    ESP_STYLE_GLOW = 1,        
    ESP_STYLE_OUTLINED = 2,   
    ESP_STYLE_DOTTED = 3,    
    ESP_STYLE_DASHED = 4,     
    ESP_STYLE_GRADIENT = 5   
};

struct Config {

    bool show_box_esp = true;
    bool show_skeleton_esp = true;
    bool show_head_tracker = true;
    bool show_health_bar = true;
    bool show_armor_bar = true;
    bool show_snaplines = false;
    bool show_names = true;
    bool show_distance = true;
    bool show_filled_box = false;

    bool use_corner_box = false;

    int box_thickness = 1;
    int skeleton_thickness = 1;
    int snapline_thickness = 1;
    int filled_box_alpha = 50;

    ESPLineStyle esp_line_style = ESP_STYLE_NORMAL;

    int glow_intensity = 3;         
    int glow_blur_radius = 8;       
    float glow_alpha_falloff = 0.5f; 

    int outline_thickness = 2;       
    struct Color { int r, g, b; };
    Color outline_color = { 0, 0, 0 }; 

    int dot_spacing = 5;              
    int dot_length = 3;              

    Color box_color_team = { 0, 255, 0 };
    Color box_color_enemy = { 255, 0, 0 };
    Color skeleton_color_team = { 0, 255, 0 };
    Color skeleton_color_enemy = { 255, 0, 0 };
    Color head_color_team = { 0, 255, 0 };
    Color head_color_enemy = { 255, 0, 0 };
    Color filled_box_color_team = { 0, 255, 0 };
    Color filled_box_color_enemy = { 255, 0, 0 };

    bool show_bomb_timer = true;
    bool show_radar = true;
    bool fov_changer_enabled = false;
    int fov_value = 90;
    bool bhop_enabled = false;
    int bhop_delay = 5;

    bool team_esp = true;
    bool ignore_teammates = false;
    bool ignore_enemies = false;
    float render_distance = 10000.0f;

    bool radar_show_names = true;
    float radar_size = 200.0f;
    float radar_x = 50.0f;
    float radar_y = 50.0f;
    float radar_zoom = 1000.0f;

    float bomb_timer_x = 100.0f;
    float bomb_timer_y = 100.0f;

    int desired_fov = 90;
    bool fov_ignore_scope = true;

    bool glow_enabled = false;
    bool glow_enemies = true;
    bool glow_teammates = false;
    int glow_type = 3;
    int glow_alpha = 255;

    Color glow_color_enemy = { 255, 0, 0 };
    Color glow_color_team = { 0, 255, 0 };

    bool use_memory_manager = true;
    bool use_batch_reading = true;
    bool use_async_reading = true;
    bool use_cache = true;
    int cache_lifetime_ms = 100;
    bool cache_player_names = true;
    bool cache_static_data = true;
    bool use_dynamic_lod = true;
    float lod_distance_near = 2000.0f;
    float lod_distance_medium = 5000.0f;
    float lod_distance_far = 10000.0f;
    bool disable_skeleton_far = true;
    bool frustum_culling = true;
    bool distance_culling = true;
    float max_render_distance = 15000.0f;
    bool occlusion_culling = false;
    int esp_update_rate_ms = 16;
    int player_data_update_rate_ms = 50;
    int static_data_update_rate_ms = 1000;
    bool sort_by_distance = true;
    bool sort_by_visibility = false;
    int max_visible_players = 64;
    bool show_performance_stats = true;
    bool show_memory_stats = true;
    bool show_detailed_stats = false;
    bool log_performance = false;
    bool use_multithreading = true;
    int worker_threads = 2;
    int thread_priority = 0;
    bool batch_render_calls = true;
    bool skip_offscreen_render = true;
    bool use_render_queue = false;
    bool pre_allocate_buffers = true;
    int buffer_pool_size = 64;
    bool reuse_buffers = true;
    bool debug_mode = false;
    bool show_read_times = false;
    bool show_render_times = false;
    bool show_frame_budget = false;

    enum PerformancePreset {
        PRESET_ULTRA_PERFORMANCE,
        PRESET_BALANCED,
        PRESET_QUALITY,
        PRESET_CUSTOM
    };

    PerformancePreset current_preset = PRESET_BALANCED;

    void ApplyPreset(PerformancePreset preset) {
        current_preset = preset;
        switch (preset) {
        case PRESET_ULTRA_PERFORMANCE:
            show_skeleton_esp = false;
            show_filled_box = false;
            show_snaplines = false;
            use_dynamic_lod = true;
            max_render_distance = 5000.0f;
            esp_update_rate_ms = 32;
            cache_lifetime_ms = 200;
            use_batch_reading = true;
            use_async_reading = true;
            frustum_culling = true;
            distance_culling = true;
            break;
        case PRESET_BALANCED:
            show_skeleton_esp = true;
            show_filled_box = false;
            show_snaplines = false;
            use_dynamic_lod = true;
            max_render_distance = 10000.0f;
            esp_update_rate_ms = 16;
            cache_lifetime_ms = 100;
            use_batch_reading = true;
            use_async_reading = true;
            frustum_culling = true;
            distance_culling = true;
            break;
        case PRESET_QUALITY:
            show_skeleton_esp = true;
            show_filled_box = true;
            show_snaplines = true;
            use_dynamic_lod = false;
            max_render_distance = 20000.0f;
            esp_update_rate_ms = 8;
            cache_lifetime_ms = 50;
            use_batch_reading = true;
            use_async_reading = true;
            frustum_culling = false;
            distance_culling = false;
            break;
        case PRESET_CUSTOM:
            break;
        }
    }

    float GetFrameBudget() const {
        return 1000.0f / (1000.0f / esp_update_rate_ms);
    }

    bool ShouldRenderPlayer(float distance) const {
        if (!distance_culling) return true;
        return distance <= max_render_distance;
    }

    int GetLODLevel(float distance) const {
        if (!use_dynamic_lod) return 0;
        if (distance <= lod_distance_near) return 0;
        if (distance <= lod_distance_medium) return 1;
        if (distance <= lod_distance_far) return 2;
        return 3;
    }
};

extern Config g_config;

class ConfigLoader {
public:
    static void LoadConfig();
    static void SaveConfig();
    static void LoadDefaultConfig();
    static void LoadPerformanceConfig();
    static void SavePerformanceConfig();
};