#pragma once
#include "common.h"
#include <d3d11.h>

namespace ImGuiMenu {
    extern bool g_ShowMenu;
    extern bool g_Initialized;

    bool Initialize(HWND hwnd, ID3D11Device* device, ID3D11DeviceContext* context);
    void Shutdown();
    void BeginFrame();
    void Render();
    void EndFrame();

    void RenderMainMenu();
    void RenderESPSettings();
    void RenderRadarSettings();
    void RenderBombTimerSettings();
    void RenderTriggerBotSettings();
    void RenderGlowSettings();
    void RenderMiscSettings();
    void RenderKeybindsSettings();
    void RenderCredits();  
}